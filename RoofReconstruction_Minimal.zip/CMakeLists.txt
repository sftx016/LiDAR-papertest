cmake_minimum_required(VERSION 3.12)
project(RoofReconstruction LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(MSVC)
    add_compile_definitions(WIN32 _CRT_SECURE_NO_WARNINGS)
    add_compile_options("$<$<COMPILE_LANGUAGE:CXX>:/bigobj>" "$<$<COMPILE_LANGUAGE:CXX>:/EHsc>")
endif()

set(CITY3D_RANSAC_SOURCE_DIR "" CACHE PATH "Compatible RANSAC_SD_orig source directory")
if(NOT EXISTS "${CITY3D_RANSAC_SOURCE_DIR}/RANSAC_PointCloud.h"
   OR NOT EXISTS "${CITY3D_RANSAC_SOURCE_DIR}/RansacShapeDetector.cpp"
   OR NOT IS_DIRECTORY "${CITY3D_RANSAC_SOURCE_DIR}/MiscLib"
   OR NOT IS_DIRECTORY "${CITY3D_RANSAC_SOURCE_DIR}/GfxTL")
    message(FATAL_ERROR "Set CITY3D_RANSAC_SOURCE_DIR to the compatible RANSAC source described in README.md.")
endif()

file(GLOB ransac_sources CONFIGURE_DEPENDS
    "${CITY3D_RANSAC_SOURCE_DIR}/*.cpp"
    "${CITY3D_RANSAC_SOURCE_DIR}/GfxTL/*.cpp"
    "${CITY3D_RANSAC_SOURCE_DIR}/MiscLib/*.cpp")
add_library(roof_ransac STATIC ${ransac_sources})
target_include_directories(roof_ransac PUBLIC "${CITY3D_RANSAC_SOURCE_DIR}")
target_include_directories(roof_ransac PRIVATE
    "${CITY3D_RANSAC_SOURCE_DIR}/GfxTL"
    "${CITY3D_RANSAC_SOURCE_DIR}/MiscLib")
target_compile_definitions(roof_ransac PRIVATE TIMINGLEVEL0 $<$<CONFIG:Release>:TIMINGLEVEL1>)
if(MSVC)
    target_compile_options(roof_ransac PRIVATE /FItime.h)
    target_compile_definitions(roof_ransac PRIVATE _LIB _CRT_SECURE_NO_DEPRECATE _SCL_SECURE_NO_WARNINGS)
endif()

set(CITY3D_SOLVER_SOURCE_DIR "" CACHE PATH "Optional original directory containing 3rd_scip and 3rd_soplex")
if(CITY3D_SOLVER_SOURCE_DIR)
    set(POLYFIT_scip_DIR "${CITY3D_SOLVER_SOURCE_DIR}/3rd_scip")
    set(POLYFIT_soplex_DIR "${CITY3D_SOLVER_SOURCE_DIR}/3rd_soplex")
    add_subdirectory("${POLYFIT_soplex_DIR}" "${CMAKE_BINARY_DIR}/soplex")
    add_subdirectory("${POLYFIT_scip_DIR}" "${CMAKE_BINARY_DIR}/scip")
    set(SCIP_LIBRARIES 3rd_scip 3rd_soplex)
    set(SCIP_INCLUDE_DIRS "${POLYFIT_scip_DIR}")
else()
    find_package(SCIP CONFIG REQUIRED)
endif()

find_package(CGAL 5.4 REQUIRED COMPONENTS Core)
find_package(OpenCV REQUIRED COMPONENTS core imgproc)
find_package(Eigen3 3.3 QUIET CONFIG)
if(NOT TARGET Eigen3::Eigen)
    find_path(EIGEN_INCLUDE_DIR Eigen/Core PATH_SUFFIXES eigen3)
    if(NOT EIGEN_INCLUDE_DIR)
        message(FATAL_ERROR "Install Eigen or set EIGEN_INCLUDE_DIR to the directory containing Eigen/Core.")
    endif()
endif()

file(GLOB_RECURSE geometry_sources CONFIGURE_DEPENDS
    "src/basic/*.cpp" "src/math/*.cpp" "src/model/*.cpp")
add_library(roof_geometry STATIC ${geometry_sources} third_party/rply/rply.c)
target_include_directories(roof_geometry PUBLIC ${SCIP_INCLUDE_DIRS} PRIVATE third_party/rply)
target_link_libraries(roof_geometry PUBLIC ${SCIP_LIBRARIES})

file(GLOB method_sources CONFIGURE_DEPENDS "src/method/*.cpp")
add_library(roof_method STATIC ${method_sources})
target_include_directories(roof_method PRIVATE ${OpenCV_INCLUDE_DIRS})
target_compile_definitions(roof_method PRIVATE
    CGAL_triangulation_precondition=CGAL_precondition
    CGAL_triangulation_postcondition=CGAL_postcondition)
target_link_libraries(roof_method PUBLIC roof_geometry roof_ransac
    CGAL::CGAL CGAL::CGAL_Core ${OpenCV_LIBS})
if(TARGET Eigen3::Eigen)
    target_link_libraries(roof_method PRIVATE Eigen3::Eigen)
else()
    target_include_directories(roof_method PRIVATE "${EIGEN_INCLUDE_DIR}")
endif()

add_executable(roof_reconstruct src/main.cpp)
target_include_directories(roof_reconstruct PRIVATE src)
target_link_libraries(roof_reconstruct PRIVATE roof_method)
