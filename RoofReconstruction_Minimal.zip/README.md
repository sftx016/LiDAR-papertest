# Roof Reconstruction

A command-line version of the City3D-based reconstruction workflow. It takes a point cloud in PLY format and building footprints in OBJ format, in the same coordinate system and in metres. It exports validated, per-footprint shells as an OBJ. The default mode uses guarded facet selection with the P95 feedback pass.

## Dependencies

- A C++14 compiler, CMake 3.12 or newer and a build tool such as Ninja.
- CGAL 5.x (5.4 or later) with Boost and GMP/MPFR, OpenCV (`core` and `imgproc`), and Eigen 3.3 or newer.
- A SCIP installation with its CMake package config, or the original SCIP and SoPlex source directories as described below.
- The compatible Efficient RANSAC source tree used in the experiments. Set `CITY3D_RANSAC_SOURCE_DIR` to the directory containing `RANSAC_PointCloud.h`, `RansacShapeDetector.cpp`, `GfxTL/`, and `MiscLib/`. Obtain this source from the experiment authors or use a compatible copy you already have. This build uses the `RANSAC_PointCloud` API.

## Build

On Windows, run from an x64 developer shell. Adjust the paths to the dependencies installed on your system. If CMake already finds a dependency, its path argument can be omitted.

```powershell
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_TRY_COMPILE_CONFIGURATION=Release `
  "-DCITY3D_RANSAC_SOURCE_DIR=C:/deps/RANSAC_SD_orig" `
  "-DSCIP_DIR=C:/deps/scip/lib/cmake/scip" `
  "-DCGAL_DIR=C:/deps/CGAL" "-DBOOST_ROOT=C:/deps/boost" `
  "-DOpenCV_DIR=C:/deps/opencv/build" "-DEIGEN_INCLUDE_DIR=C:/deps/eigen"
cmake --build build
```

CMake 3.12 uses `-H. -Bbuild` in place of `-S . -B build`. For the original SCIP 8.0.3 and SoPlex 3.1.1 backend, use CMake 3.x and replace the `SCIP_DIR` argument with `-DCITY3D_SOLVER_SOURCE_DIR=C:/deps/original-third-party`. That directory must contain the original `3rd_scip/` and `3rd_soplex/` directories and their CMake files. On Windows, shared-library builds require the OpenCV, CGAL dependency, and SCIP DLL directories on `PATH` as applicable.

## Run

```powershell
.\build\roof_reconstruct.exe cloud.ply footprint.obj refined.obj
```

Use `guarded` as the fourth argument for the baseline pipeline. Use `compare-refined` for a per-building CSV and optional paired baseline exports.

```powershell
.\build\roof_reconstruct.exe cloud.ply footprint.obj refined.obj compare-refined refined.csv baseline.obj baseline.csv
```

The paired command generates each building's candidate set once and evaluates both outputs on it. Use the `guarded` rows and `shell_p95_after` for the final roof-distance P95. The `shell_status` field records the per-footprint validation result. Separate runs can vary because the external RANSAC detector uses a time-based seed.

Verified on Windows x64 with MSVC 2017, CGAL 5.6.3, Boost 1.68.0, OpenCV 4.5.5 and Eigen 3.3.7. Both SCIP 9.2.4 and the original SCIP/SoPlex backend built and ran the paired command on the 003 data. In both tests, 361 of 368 footprints produced shells that passed the independent geometry audit in both arms.

## Supervoxel

**The latest supervoxel implementation is coming soon.** The `supervoxel` mode is reserved for that release.

```powershell
.\build\roof_reconstruct.exe cloud.ply footprint.obj supervoxel.obj supervoxel
```

This entry currently prints the release notice and exits before loading the inputs or writing an output.

## Source layout

- `src/method/reconstruction.cpp` runs segmentation, candidate generation, shell construction and validation.
- `src/method/face_selection_scores.cpp` and `src/method/face_selection_optimization.cpp` implement facet scoring, the ILP and the feedback passes.
- `src/main.cpp` provides the command-line entry point. `src/basic/`, `src/math/` and `src/model/` provide supporting code.

## Attribution

This CLI package is derived from [City3D](https://github.com/tudelft3d/City3D). The 2026-11-22 packaging changes provide a headless entry point and limit input/output to PLY and OBJ. Original source notices and the project license are included. [City3D license](https://github.com/tudelft3d/City3D/blob/main/LICENSE)

The bundled RPly source carries its MIT license notice. The externally supplied RANSAC and solver libraries have their own notices and terms. [Efficient RANSAC](https://cg.cs.uni-bonn.de/publication/schnabel-2007-efficient) · [SoPlex 3.1.1 license](https://soplex.zib.de/doc-3.1.1/html/LICENSE.php)

