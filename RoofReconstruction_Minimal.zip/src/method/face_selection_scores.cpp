#include "face_selection_scores.h"

#include "alpha_shape_mesh.h"
#include "../math/principal_axes.h"
#include "../model/kdtree_search.h"
#include "../model/map_circulators.h"
#include "../model/point_set.h"

#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/point_xy.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <map>
#include <set>
#include <tuple>
#include <utility>

namespace FaceSelectionScores {
namespace {

namespace bg = boost::geometry;
using Point2 = bg::model::d2::point_xy<double>;
using Box = bg::model::box<Point2>;
using Polygon = bg::model::polygon<Point2>;
using Polygons = std::vector<Polygon>;

constexpr double pi = 3.14159265358979323846;
constexpr double distance_tolerance = 0.10;
constexpr double normal_tolerance = 20.0 * pi / 180.0;
constexpr double ridge_min_angle = 10.0 * pi / 180.0;
constexpr double boundary_max_angle = 15.0 * pi / 180.0;
constexpr double epsilon = 1e-9;
constexpr std::size_t invalid_sample = std::numeric_limits<std::size_t>::max();

double unit_interval(double value) {
    return std::max(0.0, std::min(1.0, value));
}

vec2 xy(const vec3& point) {
    return vec2(point.x, point.y);
}

double cross_xy(const vec2& a, const vec2& b) {
    return a.x * b.y - a.y * b.x;
}

std::vector<vec2> project_facet(Map::Facet* facet, const vec2& origin) {
    std::vector<vec2> vertices;
    FacetHalfedgeCirculator ring(facet);
    for (; !ring->end(); ++ring) {
        const vec2 projected = xy(ring->halfedge()->vertex()->point()) - origin;
        if (vertices.empty() || length2(vertices.back() - projected) > epsilon * epsilon)
            vertices.push_back(projected);
    }
    if (vertices.size() > 1 && length2(vertices.front() - vertices.back()) <= epsilon * epsilon)
        vertices.pop_back();
    return vertices;
}

Polygon make_polygon(const std::vector<vec2>& vertices) {
    Polygon polygon;
    for (const vec2& point : vertices)
        polygon.outer().emplace_back(point.x, point.y);
    bg::correct(polygon);
    return polygon;
}

double area(const Polygons& polygons) {
    double total = 0.0;
    for (const Polygon& polygon : polygons)
        total += bg::area(polygon);
    return total;
}

Polygons clip_roof(const Polygon& footprint, const std::vector<vec2>& outline) {
    const Polygon candidate = make_polygon(outline);
    Polygons clipped;
    if (bg::area(candidate) > epsilon && bg::is_valid(candidate))
        bg::intersection(footprint, candidate, clipped);
    return clipped;
}

struct ProjectedRoof {
    std::size_t index;
    Polygons components;
    Box bounds;
};

bool overlaps(const ProjectedRoof& first, const ProjectedRoof& second, double tolerance) {
    if (first.bounds.max_corner().y() <= second.bounds.min_corner().y() ||
        second.bounds.max_corner().y() <= first.bounds.min_corner().y())
        return false;

    // Footprint clipping can split a roof polygon into several disjoint pieces.
    double common_area = 0.0;
    for (const auto& a : first.components) {
        for (const auto& b : second.components) {
            Polygons common;
            bg::intersection(a, b, common);
            common_area += area(common);
            if (common_area > tolerance)
                return true;
        }
    }
    return false;
}

bool contains(const Polygons& polygons, const vec2& point) {
    const Point2 projected(point.x, point.y);
    for (const Polygon& polygon : polygons) {
        if (bg::covered_by(projected, polygon))
            return true;
    }
    return false;
}

bool is_convex(const Polygons& polygons) {
    if (polygons.size() != 1 || !polygons.front().inners().empty())
        return false;
    const auto& ring = polygons.front().outer();
    const std::size_t count = ring.size() - 1;
    for (std::size_t i = 0; i < count; ++i) {
        const auto& a = ring[i];
        const auto& b = ring[(i + 1) % count];
        const auto& c = ring[(i + 2) % count];
        const double turn = (b.x() - a.x()) * (c.y() - b.y()) - (b.y() - a.y()) * (c.x() - b.x());
        if (turn > 0.0)
            return false;
    }
    return true;
}

double quantile(std::vector<double> values, double probability) {
    if (values.empty())
        return 0.0;
    const double position = probability * static_cast<double>(values.size() - 1);
    const auto upper = values.begin() + static_cast<std::size_t>(std::ceil(position));
    std::nth_element(values.begin(), upper, values.end());
    const double fraction = position - std::floor(position);
    if (fraction == 0.0)
        return *upper;
    return (1.0 - fraction) * *std::max_element(values.begin(), upper) + fraction * *upper;
}

double normal_angle(const vec3& a, const vec3& b) {
    const double magnitude = length(a) * length(b);
    return magnitude > epsilon
        ? std::acos(unit_interval(std::abs(dot(a, b)) / magnitude))
        : std::numeric_limits<double>::quiet_NaN();
}

struct RoofSamples {
    std::vector<vec3> points;
    std::vector<std::size_t> ids;
    std::vector<double> variations;
    KdTreeSearch tree;
    double spacing = distance_tolerance;

    RoofSamples(const PointSet& pset, const std::vector<Facet>& facets)
        : ids(pset.points().size(), invalid_sample) {
        std::set<const VertexGroup*> groups;
        std::map<std::tuple<double, double, double>, std::size_t> unique;
        for (const Facet& facet : facets) {
            if (!facet.roof || !facet.group || !groups.insert(facet.group).second)
                continue;
            for (unsigned int index : *facet.group) {
                if (index >= ids.size())
                    continue;
                const vec3& point = pset.points()[index];
                if (!std::isfinite(point.x) || !std::isfinite(point.y) || !std::isfinite(point.z))
                    continue;
                const auto entry = unique.emplace(std::make_tuple(point.x, point.y, point.z), points.size());
                ids[index] = entry.first->second;
                if (entry.second)
                    points.push_back(point);
            }
        }
        if (points.size() < 2)
            return;

        tree.begin();
        for (vec3& point : points)
            tree.add_point(&point);
        tree.end();

        std::vector<double> distances;
        std::vector<unsigned int> neighbors;
        std::vector<double> nearest_distances;
        for (const vec3& point : points) {
            tree.find_closest_K_points(point, 2, neighbors, distances);
            if (distances.size() == 2 && distances[1] > epsilon * epsilon)
                nearest_distances.push_back(std::sqrt(distances[1]));
        }
        if (!nearest_distances.empty())
            spacing = quantile(std::move(nearest_distances), 0.5);
        variations.resize(points.size(), std::numeric_limits<double>::quiet_NaN());
    }

    double variation(std::size_t sample) {
        if (points.size() < 13)
            return -1.0;
        double& value = variations[sample];
        if (!std::isnan(value))
            return value;
        value = -1.0;

        std::vector<unsigned int> neighbors;
        std::vector<double> distances;
        tree.find_closest_K_points(points[sample],
            static_cast<unsigned int>(std::min<std::size_t>(25, points.size())), neighbors, distances);

        PrincipalAxes3d pca;
        pca.begin();
        std::size_t count = 0;
        const double radius_squared = 16.0 * spacing * spacing;
        for (std::size_t i = 0; i < neighbors.size(); ++i) {
            if (neighbors[i] != sample && distances[i] <= radius_squared) {
                // Recentering avoids cancellation with georeferenced coordinates.
                pca.add_point(points[neighbors[i]] - points[sample]);
                ++count;
            }
        }
        if (count < 12)
            return value;
        pca.end();

        const double sum = pca.eigen_value(0) + pca.eigen_value(1) + pca.eigen_value(2);
        if (sum > epsilon * epsilon)
            value = std::max(0.0, pca.eigen_value(2) / sum);
        return value;
    }
};

struct FacetData {
    std::vector<vec2> vertices;
    std::vector<std::size_t> support;
};

double clipped_support_area(PointSet* pset, VertexGroup& points, double radius, const vec2& origin,
                            const Polygons& clipped_facet) {
    if (points.size() < 3)
        return 0.0;
    points.set_point_set(pset);
    Map::Ptr alpha_mesh = AlphaShapeMesh::apply(&points, radius);
    if (!alpha_mesh)
        return 0.0;

    // Alpha-shape interior triangles have disjoint interiors, even after clipping.
    const bool convex = is_convex(clipped_facet);
    double covered = 0.0;
    FOR_EACH_FACET(Map, alpha_mesh, it) {
        const Polygon triangle = make_polygon(project_facet(it, origin));
        const double triangle_area = bg::area(triangle);
        if (triangle_area <= epsilon)
            continue;
        if (convex) {
            // All alpha-shape vertices were tested inside the convex face.
            covered += triangle_area;
            continue;
        }
        for (const Polygon& component : clipped_facet) {
            Polygons intersection;
            bg::intersection(triangle, component, intersection);
            covered += area(intersection);
        }
    }
    return covered;
}

double perpendicular_distance(const vec2& point, const vec2& a, const vec2& b) {
    const vec2 edge = b - a;
    const double edge_squared = length2(edge);
    if (edge_squared <= epsilon * epsilon)
        return length(point - a);
    const double position = unit_interval(dot(point - a, edge) / edge_squared);
    return length(point - (a + position * edge));
}

bool point_is_interior(const vec2& point, const std::vector<vec2>& ring, double band) {
    for (std::size_t i = 0; i < ring.size(); ++i) {
        if (perpendicular_distance(point, ring[i], ring[(i + 1) % ring.size()]) < band)
            return false;
    }
    return true;
}

struct RidgePart {
    double length;
    std::vector<std::size_t> samples;
};

struct RidgeEvidence {
    std::size_t first, second, edge;
    std::vector<RidgePart> parts;
};

using EdgeSideSamples = std::array<std::vector<std::size_t>, 2>;

std::vector<EdgeSideSamples> near_edge(const Edge& edge, const std::vector<std::size_t>& support,
                                      const RoofSamples& roof, std::size_t parts) {
    std::vector<EdgeSideSamples> result(parts);
    const vec3 direction = edge.b - edge.a;
    const double squared_length = length2(direction);
    const double band = 2.0 * roof.spacing;
    for (std::size_t id : support) {
        const vec3 offset = roof.points[id] - edge.a;
        const double position = dot(offset, direction) / squared_length;
        if (position < 0.0 || position > 1.0)
            continue;
        if (length2(offset - position * direction) > band * band)
            continue;
        const double side = cross_xy(xy(direction), xy(offset));
        if (std::abs(side) <= epsilon)
            continue;
        const std::size_t part = std::min(parts - 1, static_cast<std::size_t>(position * parts));
        result[part][side > 0.0 ? 1 : 0].push_back(id);
    }
    return result;
}

std::vector<RidgePart> corroborated_parts(const std::vector<EdgeSideSamples>& first,
                                         const std::vector<EdgeSideSamples>& second,
                                         double length) {
    std::vector<RidgePart> parts;
    for (std::size_t i = 0; i < first.size(); ++i) {
        const std::size_t support_left = std::min(first[i][0].size(), second[i][1].size());
        const std::size_t support_right = std::min(first[i][1].size(), second[i][0].size());
        if (std::max(support_left, support_right) < 3)
            continue;
        const std::size_t side = support_right > support_left ? 1 : 0;
        RidgePart part{length / first.size(), first[i][side]};
        part.samples.insert(part.samples.end(), second[i][1 - side].begin(), second[i][1 - side].end());
        parts.push_back(std::move(part));
    }
    return parts;
}

void score_ridges(const std::vector<Facet>& facets, const std::vector<FacetData>& data,
                  const std::vector<Edge>& edges, const std::vector<bool>& interior,
                  double perimeter, RoofSamples& roof, Result& result) {
    std::vector<RidgeEvidence> evidence;
    std::vector<bool> in_ridge(roof.points.size(), false);
    double total_length = 0.0;
    for (std::size_t e = 0; e < edges.size(); ++e) {
        const Edge& edge = edges[e];
        const double edge_length = length(xy(edge.b - edge.a));
        if (edge_length <= epsilon || edge.facets.size() < 2)
            continue;

        const std::size_t bins = static_cast<std::size_t>(std::ceil(edge_length / (4.0 * roof.spacing)));
        std::map<std::size_t, std::vector<EdgeSideSamples>> samples;
        const std::size_t before = evidence.size();
        for (std::size_t a : edge.facets) {
            if (!facets[a].roof || !facets[a].plane || data[a].support.empty())
                continue;
            for (std::size_t b : edge.facets) {
                if (a >= b || !facets[b].roof || !facets[b].plane || data[b].support.empty())
                    continue;
                const double angle = normal_angle(facets[a].plane->normal(), facets[b].plane->normal());
                if (!(angle >= ridge_min_angle))
                    continue;
                auto first = samples.find(a);
                if (first == samples.end())
                    first = samples.emplace(a, near_edge(edge, data[a].support, roof, bins)).first;
                auto second = samples.find(b);
                if (second == samples.end())
                    second = samples.emplace(b, near_edge(edge, data[b].support, roof, bins)).first;
                auto parts = corroborated_parts(first->second, second->second, edge_length);
                if (parts.empty())
                    continue;
                for (const RidgePart& part : parts) {
                    for (std::size_t sample : part.samples)
                        in_ridge[sample] = true;
                }
                evidence.push_back(RidgeEvidence{a, b, e, std::move(parts)});
            }
        }
        if (evidence.size() != before)
            total_length += edge_length;
    }

    if (evidence.empty())
        return;
    std::vector<double> interior_variations, ridge_variations;
    for (std::size_t i = 0; i < roof.points.size(); ++i) {
        if (!interior[i] && !in_ridge[i])
            continue;
        const double value = roof.variation(i);
        if (value < 0.0)
            continue;
        if (in_ridge[i])
            ridge_variations.push_back(value);
        else if (interior[i])
            interior_variations.push_back(value);
    }
    const double noise = quantile(std::move(interior_variations), 0.9);
    const double scale = std::max(0.005, quantile(std::move(ridge_variations), 0.95) - noise);
    const double reference = std::max(perimeter, total_length);

    for (const RidgeEvidence& ridge : evidence) {
        double length_weighted_score = 0.0;
        for (const RidgePart& part : ridge.parts) {
            std::vector<double> normalized;
            for (std::size_t sample : part.samples) {
                const double value = roof.variation(sample);
                if (value >= 0.0)
                    normalized.push_back(unit_interval((value - noise) / scale));
            }
            length_weighted_score += part.length * quantile(std::move(normalized), 0.5);
        }
        if (length_weighted_score > 0.0)
            result.ridges.push_back(Ridge{ridge.first, ridge.second, ridge.edge, length_weighted_score / reference});
    }
}

struct BoundaryEvent {
    double position;
    std::size_t facet;
    int delta;
};

void add_boundary_events(const vec2& a, const vec2& direction, double boundary_length, const Edge& candidate,
                         double tolerance, std::vector<BoundaryEvent>& events) {
    const vec2 start = xy(candidate.a) - a;
    const vec2 edge_delta = xy(candidate.b - candidate.a);
    const double edge_length = length(edge_delta);
    const double along = dot(direction, edge_delta);
    if (edge_length <= epsilon || std::abs(along) < edge_length * std::cos(boundary_max_angle))
        return;

    const double distance_at_start = cross_xy(direction, start);
    const double distance_delta = cross_xy(direction, edge_delta);
    double begin = 0.0, end = 1.0;
    if (std::abs(distance_delta) <= epsilon) {
        if (std::abs(distance_at_start) > tolerance)
            return;
    } else {
        const double entry = (-tolerance - distance_at_start) / distance_delta;
        const double exit = (tolerance - distance_at_start) / distance_delta;
        begin = std::max(begin, std::min(entry, exit));
        end = std::min(end, std::max(entry, exit));
    }
    if (end <= begin)
        return;
    const double base = dot(direction, start);
    const double p = base + along * begin;
    const double q = base + along * end;
    const double low = std::max(0.0, std::min(p, q));
    const double high = std::min(boundary_length, std::max(p, q));
    if (high - low > epsilon) {
        events.push_back(BoundaryEvent{low, candidate.facets.front(), 1});
        events.push_back(BoundaryEvent{high, candidate.facets.front(), -1});
    }
}

void score_boundary(const std::vector<vec2>& footprint, const vec2& origin,
                    const std::vector<Facet>& facets, const std::vector<Edge>& edges,
                    double perimeter, double spacing, Result& result) {
    const double tolerance = std::max(distance_tolerance, std::min(0.50, 2.0 * spacing));
    std::map<std::vector<std::size_t>, double> matching_lengths;
    for (std::size_t i = 0; i < footprint.size(); ++i) {
        const vec2& a = footprint[i];
        const vec2 side = footprint[(i + 1) % footprint.size()] - a;
        const double side_length = length(side);
        if (side_length <= epsilon)
            continue;
        std::vector<BoundaryEvent> events;
        for (const Edge& edge : edges) {
            if (edge.facets.size() == 1 && facets[edge.facets.front()].roof)
                add_boundary_events(a + origin, side / side_length, side_length, edge, tolerance, events);
        }
        std::sort(events.begin(), events.end(), [](const BoundaryEvent& lhs, const BoundaryEvent& rhs) {
            return lhs.position < rhs.position;
        });

        std::map<std::size_t, int> active;
        double previous = 0.0;
        for (const BoundaryEvent& event : events) {
            const double interval = event.position - previous;
            if (interval > epsilon && !active.empty()) {
                std::vector<std::size_t> contributing;
                for (const auto& cover : active)
                    contributing.push_back(cover.first);
                matching_lengths[contributing] += interval;
            }
            if ((active[event.facet] += event.delta) == 0)
                active.erase(event.facet);
            previous = event.position;
        }
    }
    for (const auto& match : matching_lengths)
        result.boundary.push_back(Boundary{match.first, match.second / perimeter});
}

} // namespace

std::vector<std::pair<std::size_t, std::size_t>> overlapping_roofs(
    Map::Facet* footprint, const std::vector<Facet>& facets) {
    std::vector<std::pair<std::size_t, std::size_t>> conflicts;
    if (!footprint || footprint->degree() < 3)
        return conflicts;

    // Local XY coordinates keep the tests stable for georeferenced inputs.
    const vec2 origin = xy(footprint->halfedge()->vertex()->point());
    const Polygon outline = make_polygon(project_facet(footprint, origin));
    const double footprint_area = bg::area(outline);
    if (!(footprint_area > epsilon) || !bg::is_valid(outline))
        return conflicts;

    // Ignore sub-tolerance slivers from numerical intersections at shared edges.
    const double tolerance = std::max(1e-6, 1e-7 * footprint_area);
    std::vector<ProjectedRoof> roofs;
    roofs.reserve(facets.size());
    for (std::size_t i = 0; i < facets.size(); ++i) {
        if (!facets[i].roof || !facets[i].face)
            continue;
        Polygons components = clip_roof(outline, project_facet(facets[i].face, origin));
        if (area(components) <= tolerance)
            continue;

        Box bounds;
        bg::assign_inverse(bounds);
        for (const Polygon& component : components) {
            Box component_bounds;
            bg::envelope(component, component_bounds);
            bg::expand(bounds, component_bounds);
        }
        roofs.push_back(ProjectedRoof{i, std::move(components), bounds});
    }

    std::sort(roofs.begin(), roofs.end(), [](const ProjectedRoof& a, const ProjectedRoof& b) {
        return a.bounds.min_corner().x() < b.bounds.min_corner().x();
    });
    for (std::size_t i = 0; i < roofs.size(); ++i) {
        for (std::size_t j = i + 1; j < roofs.size(); ++j) {
            if (roofs[j].bounds.min_corner().x() >= roofs[i].bounds.max_corner().x())
                break;
            if (overlaps(roofs[i], roofs[j], tolerance))
                conflicts.emplace_back(std::min(roofs[i].index, roofs[j].index),
                                       std::max(roofs[i].index, roofs[j].index));
        }
    }
    std::sort(conflicts.begin(), conflicts.end());
    return conflicts;
}

Result compute(PointSet* pset, Map::Facet* footprint, const std::vector<Facet>& facets,
               const std::vector<Edge>& edges, bool full) {
    Result result;
    result.support.resize(facets.size(), 0.0);
    result.area_penalty.resize(facets.size(), 0.0);
    result.coverage.resize(facets.size(), 0.0);
    result.xy_area.resize(facets.size(), 0.0);

    if (!pset || !footprint || footprint->degree() < 3)
        return result;
    const vec2 origin = xy(footprint->halfedge()->vertex()->point());
    const auto outline = project_facet(footprint, origin);
    const Polygon footprint_polygon = make_polygon(outline);
    const double footprint_area = bg::area(footprint_polygon);
    if (!(footprint_area > epsilon) || !bg::is_valid(footprint_polygon))
        return result;

    double perimeter = 0.0;
    for (std::size_t i = 0; i < outline.size(); ++i)
        perimeter += length(outline[i] - outline[(i + 1) % outline.size()]);

    RoofSamples roof(*pset, facets);
    const auto& normals = pset->normals();
    std::vector<FacetData> data(facets.size());
    std::vector<bool> interior(roof.points.size(), false);
    double candidate_area = 0.0;
    std::size_t candidate_count = 0;
    for (std::size_t i = 0; i < facets.size(); ++i) {
        const Facet& facet = facets[i];
        if (!facet.roof || !facet.face || !facet.plane)
            continue;
        data[i].vertices = project_facet(facet.face, origin);
        const Polygons clipped = clip_roof(footprint_polygon, data[i].vertices);
        const double clipped_area = area(clipped);
        if (!(clipped_area > epsilon))
            continue;
        result.xy_area[i] = clipped_area;
        candidate_area += clipped_area;
        ++candidate_count;
        if (!facet.group)
            continue;

        VertexGroup supporting(pset);
        supporting.set_plane(*facet.plane);
        std::vector<double> distances, deviations;
        std::set<std::size_t> used;
        const vec3 normal = facet.plane->normal();
        for (unsigned int id : *facet.group) {
            if (id >= roof.ids.size())
                continue;
            const std::size_t unique = roof.ids[id];
            if (unique == invalid_sample || used.count(unique))
                continue;
            const vec3& point = roof.points[unique];
            const double distance = std::sqrt(facet.plane->squared_ditance(point));
            const vec2 projected = xy(facet.plane->projection(point)) - origin;
            if (!(distance <= distance_tolerance) || !contains(clipped, projected))
                continue;

            used.insert(unique);
            supporting.push_back(id);
            distances.push_back(distance);
            const double angle = id < normals.size() ? normal_angle(normals[id], normal)
                                                     : std::numeric_limits<double>::quiet_NaN();
            if (std::isfinite(angle))
                deviations.push_back(angle);
            if (full && angle <= normal_tolerance) {
                data[i].support.push_back(unique);
                if (distance <= distance_tolerance / 2.0 &&
                    point_is_interior(projected, data[i].vertices, 2.0 * roof.spacing))
                    interior[unique] = true;
            }
        }
        const double coverage = unit_interval(clipped_support_area(pset, supporting, 5.0 * roof.spacing,
                                                                  origin, clipped) / clipped_area);
        const double residual = unit_interval(quantile(std::move(distances), 0.5) / distance_tolerance);
        const double deviation = unit_interval(quantile(std::move(deviations), 0.5) / normal_tolerance);
        result.coverage[i] = coverage;
        result.support[i] = clipped_area / footprint_area * coverage * (1.0 - 0.25 * residual - 0.25 * deviation);
    }

    if (full && candidate_count > 0) {
        const double allowed_area = std::max(candidate_area / candidate_count, 0.5 * footprint_area);
        for (std::size_t i = 0; i < facets.size(); ++i) {
            result.area_penalty[i] = std::max(0.0, result.xy_area[i] - allowed_area) / footprint_area
                * (1.0 - result.coverage[i]);
        }
        score_ridges(facets, data, edges, interior, perimeter, roof, result);
        score_boundary(outline, origin, facets, edges, perimeter, roof.spacing, result);
    }
    return result;
}

} // namespace FaceSelectionScores
