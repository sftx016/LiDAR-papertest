#pragma once

#include "../math/math_types.h"

#include <cstddef>
#include <utility>
#include <vector>

namespace RoofClosureRepair {

struct Result {
    // Pairs map each appended roof face to its original face.
    std::vector<std::pair<std::size_t, std::size_t>> added_faces;
    // Unobserved tapers are closure geometry, not fitted roof surfaces.
    std::vector<std::size_t> boundary_faces;
    std::size_t support_points = 0;
};

bool repair(std::vector<vec3>& vertices, std::vector<std::vector<std::size_t>>& faces,
            const std::vector<std::size_t>& roof_faces, std::size_t cap_face,
            const std::vector<vec3>& points, const std::vector<vec3>& normals,
            Result& result);

} // namespace RoofClosureRepair
