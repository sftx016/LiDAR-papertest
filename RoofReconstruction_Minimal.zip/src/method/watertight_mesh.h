#pragma once

#include "../model/map.h"

#include <string>
#include <vector>

namespace WatertightMesh {

struct LowRoofRepair {
    const std::vector<std::size_t>& roof_faces;
    const std::vector<vec3>& points;
    const std::vector<vec3>& normals;
    const std::vector<unsigned int>& point_indices;
    std::vector<std::size_t> added_roof_faces;
    std::size_t support_points = 0;
    std::size_t boundary_face_count = 0;
};

// Rebuild a single building shell with conforming, shared edge connectivity.
// The optional map follows the source's facet iteration order, then new roof faces.
Map::Ptr stitch(Map* source, std::string& error,
                std::vector<Map::Facet*>* stitched_faces = nullptr,
                LowRoofRepair* low_roof_repair = nullptr);

// Check an indexed, outward-facing shell without moving or welding vertices.
bool validate(Map* source, std::string& error);

} // namespace WatertightMesh
