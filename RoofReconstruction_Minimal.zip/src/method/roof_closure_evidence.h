#pragma once

#include "../math/math_types.h"

#include <cstddef>
#include <vector>

namespace RoofClosureRepair {

struct LowPlaneEvidence {
    double z = 0;
    std::size_t support = 0;
};

// Look for a supported horizontal surface where a selected roof crosses the ground.
bool find_low_plane(const std::vector<vec3>& roof, double ground_z,
                    const std::vector<vec3>& points, const std::vector<vec3>& normals,
                    LowPlaneEvidence& evidence);

} // namespace RoofClosureRepair
