#include "watertight_mesh.h"

#include "roof_closure_repair.h"
#include "watertight_validation.h"
#include "../model/map_attributes.h"
#include "../model/map_builder.h"
#include "../model/map_circulators.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <set>
#include <tuple>
#include <utility>

namespace WatertightMesh {
namespace {

// The tolerance is in the input model's coordinate units and is confined to
// one footprint. In particular, it cannot join walls of adjacent buildings.
constexpr double seam_tolerances[] = {1e-6, 1e-5, 3e-5, 1e-4};
constexpr double minimum_normal_squared = 1e-24;
constexpr double minimum_volume = 1e-16;

using Ring = std::vector<std::size_t>;
using Edge = std::pair<std::size_t, std::size_t>;

struct Shell {
    std::vector<vec3> vertices;
    std::vector<Ring> faces;
    std::vector<Map::Facet*> source_faces;
};

bool read_shell(Map* source, Shell& shell, std::string& error) {
    if (!source || source->size_of_facets() == 0) {
        error = "No faces to close";
        return false;
    }
    MapVertexAttribute<std::size_t> index(source);
    shell.vertices.reserve(source->size_of_vertices());
    FOR_EACH_VERTEX(Map, source, it) {
        const auto& p = it->point();
        if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) {
            error = "Non-finite shell vertex";
            return false;
        }
        index[it] = shell.vertices.size();
        shell.vertices.push_back(p);
    }
    FOR_EACH_FACET(Map, source, it) {
        Ring ring;
        FacetHalfedgeCirculator h(it);
        for (; !h->end(); ++h)
            ring.push_back(index[h->halfedge()->vertex()]);
        shell.faces.push_back(std::move(ring));
        shell.source_faces.push_back(it);
    }
    return true;
}

vec3 polygon_normal(const Ring& ring, const std::vector<vec3>& vertices) {
    const vec3 origin = vertices[ring.front()];
    vec3 n(0, 0, 0);
    for (std::size_t i = 0; i < ring.size(); ++i)
        n += cross(vertices[ring[i]] - origin, vertices[ring[(i + 1) % ring.size()]] - origin);
    return n;
}

bool has_area(const Ring& ring, const std::vector<vec3>& vertices) {
    return ring.size() >= 3 && length2(polygon_normal(ring, vertices)) > minimum_normal_squared;
}

void weld_vertices(Shell& shell, double tolerance) {
    const double tolerance_squared = tolerance * tolerance;
    std::vector<std::size_t> order(shell.vertices.size());
    for (std::size_t i = 0; i < order.size(); ++i)
        order[i] = i;
    // Prefer the coordinates on the appended cap. This keeps the original
    // footprint ring in place when it is almost coincident with a wall edge.
    std::vector<bool> cap_vertex(order.size(), false);
    for (const auto i : shell.faces.back())
        cap_vertex[i] = true;
    std::sort(order.begin(), order.end(), [&](std::size_t a, std::size_t b) {
        if (cap_vertex[a] != cap_vertex[b])
            return static_cast<bool>(cap_vertex[a]);
        const auto& p = shell.vertices[a];
        const auto& q = shell.vertices[b];
        return std::tie(p.z, p.x, p.y, a) < std::tie(q.z, q.x, q.y, b);
    });

    std::vector<vec3> welded;
    welded.reserve(order.size());
    std::vector<std::size_t> vertex_ids(order.size());
    std::multimap<double, std::size_t> by_x;
    for (const auto index : order) {
        const auto& p = shell.vertices[index];
        std::size_t best = welded.size();
        double best_distance = tolerance_squared;
        for (auto it = by_x.lower_bound(p.x - tolerance);
             it != by_x.end() && it->first <= p.x + tolerance; ++it) {
            const auto candidate = it->second;
            const double distance = length2(welded[candidate] - p);
            if (distance <= best_distance && (distance < best_distance || candidate < best)) {
                best = candidate;
                best_distance = distance;
            }
        }
        if (best == welded.size()) {
            by_x.emplace(p.x, best);
            welded.push_back(p);
        }
        vertex_ids[index] = best;
    }

    shell.vertices.swap(welded);
    for (auto& ring : shell.faces) {
        for (auto& id : ring)
            id = vertex_ids[id];
        ring.erase(std::unique(ring.begin(), ring.end()), ring.end());
        if (ring.size() > 1 && ring.front() == ring.back())
            ring.pop_back();
        if (!has_area(ring, shell.vertices))
            ring.clear();
    }
}

void split_seam_edges(Shell& shell, double tolerance) {
    const double tolerance_squared = tolerance * tolerance;
    std::set<std::size_t> used;
    for (const auto& face : shell.faces)
        used.insert(face.begin(), face.end());
    std::multimap<double, std::size_t> by_x;
    for (const auto i : used)
        by_x.emplace(shell.vertices[i].x, i);

    struct Split {
        std::size_t edge;
        double parameter;
        double squared_distance;
    };
    for (auto& face : shell.faces) {
        const std::set<std::size_t> ring_vertices(face.begin(), face.end());
        std::map<std::size_t, Split> nearest_edges;
        for (std::size_t j = 0; j < face.size(); ++j) {
            const auto start = face[j], end = face[(j + 1) % face.size()];
            const auto& a = shell.vertices[start];
            const auto& b = shell.vertices[end];
            const auto direction = b - a;
            const double squared_length = length2(direction);
            const double low_x = std::min(a.x, b.x) - tolerance;
            const double high_x = std::max(a.x, b.x) + tolerance;
            const double low_y = std::min(a.y, b.y) - tolerance;
            const double high_y = std::max(a.y, b.y) + tolerance;
            const double low_z = std::min(a.z, b.z) - tolerance;
            const double high_z = std::max(a.z, b.z) + tolerance;
            for (auto it = by_x.lower_bound(low_x); it != by_x.end() && it->first <= high_x; ++it) {
                const auto index = it->second;
                const auto& p = shell.vertices[index];
                if (ring_vertices.count(index) || p.y < low_y || p.y > high_y ||
                    p.z < low_z || p.z > high_z)
                    continue;
                const auto offset = p - a;
                const double t = dot(offset, direction) / squared_length;
                if (t <= 0.0 || t >= 1.0)
                    continue;
                const double squared_distance = length2(offset - t * direction);
                if (squared_distance > tolerance_squared)
                    continue;
                const auto previous = nearest_edges.find(index);
                if (previous == nearest_edges.end() || squared_distance < previous->second.squared_distance)
                    nearest_edges[index] = Split{j, t, squared_distance};
            }
        }
        // At a sharp corner, one vertex can be within tolerance of two
        // segments. Noding it twice would create a self-touching face ring.
        std::vector<std::vector<std::pair<double, std::size_t>>> subdivisions(face.size());
        for (const auto& item : nearest_edges)
            subdivisions[item.second.edge].emplace_back(item.second.parameter, item.first);
        Ring split;
        for (std::size_t j = 0; j < face.size(); ++j) {
            auto& segments = subdivisions[j];
            std::sort(segments.begin(), segments.end());
            split.push_back(face[j]);
            for (const auto& segment : segments)
                split.push_back(segment.second);
        }
        face.swap(split);
    }
}

struct Incident {
    std::size_t face;
    bool forward;
};

using Edges = std::map<Edge, std::vector<Incident>>;

bool collect_edges(const Shell& shell, Edges& edges, std::size_t& face_count, std::string& error) {
    face_count = 0;
    for (std::size_t i = 0; i < shell.faces.size(); ++i) {
        const auto& face = shell.faces[i];
        if (face.empty())
            continue;
        const std::set<std::size_t> unique(face.begin(), face.end());
        if (unique.size() != face.size() || !has_area(face, shell.vertices)) {
            error = "Degenerate or repeated-vertex shell face " + std::to_string(i);
            return false;
        }
        ++face_count;
        for (std::size_t j = 0; j < face.size(); ++j) {
            const auto a = face[j], b = face[(j + 1) % face.size()];
            edges[std::minmax(a, b)].push_back({i, a < b});
        }
    }
    if (face_count == 0) {
        error = "No non-degenerate shell faces";
        return false;
    }
    std::size_t open_edges = 0, nonmanifold_edges = 0;
    for (const auto& entry : edges) {
        open_edges += entry.second.size() == 1;
        nonmanifold_edges += entry.second.size() > 2;
    }
    if (open_edges || nonmanifold_edges) {
        error = "Shell has " + std::to_string(open_edges) + " open edges and "
            + std::to_string(nonmanifold_edges) + " non-manifold edges";
        return false;
    }
    return true;
}

bool check_vertex_links(const Edges& edges, std::size_t vertex_count, std::string& error) {
    std::vector<std::vector<Edge>> links(vertex_count);
    for (const auto& entry : edges) {
        const Edge neighbors(entry.second[0].face, entry.second[1].face);
        links[entry.first.first].push_back(neighbors);
        links[entry.first.second].push_back(neighbors);
    }
    for (const auto& link : links) {
        if (link.empty())
            continue;
        // At an edge-manifold vertex, the incident faces already have degree
        // two in the link. Check that those faces form one cycle, not several.
        std::map<std::size_t, std::vector<std::size_t>> neighbors;
        for (const auto& connected : link) {
            neighbors[connected.first].push_back(connected.second);
            neighbors[connected.second].push_back(connected.first);
        }
        std::set<std::size_t> reached;
        std::queue<std::size_t> queue;
        queue.push(neighbors.begin()->first);
        reached.insert(queue.front());
        while (!queue.empty()) {
            const auto i = queue.front();
            queue.pop();
            for (const auto j : neighbors.at(i))
                if (reached.insert(j).second)
                    queue.push(j);
        }
        if (reached.size() != neighbors.size()) {
            error = "Non-manifold shell vertex";
            return false;
        }
    }
    return true;
}

double signed_volume(const Shell& shell) {
    const vec3 origin = shell.vertices.front();
    double volume = 0.0;
    for (const auto& ring : shell.faces) {
        if (ring.empty())
            continue;
        const auto a = shell.vertices[ring.front()] - origin;
        for (std::size_t j = 1; j + 1 < ring.size(); ++j)
            volume += dot(a, cross(shell.vertices[ring[j]] - origin, shell.vertices[ring[j + 1]] - origin));
    }
    return volume / 6.0;
}

bool orient_shell(Shell& shell, bool repair_orientation, std::string& error) {
    Edges edges;
    std::size_t face_count = 0;
    if (!collect_edges(shell, edges, face_count, error) ||
        !check_vertex_links(edges, shell.vertices.size(), error))
        return false;

    std::vector<std::vector<std::pair<std::size_t, bool>>> neighbors(shell.faces.size());
    for (const auto& item : edges) {
        const auto& a = item.second[0];
        const auto& b = item.second[1];
        const bool flip = a.forward == b.forward;
        if (!repair_orientation && flip) {
            error = "Neighboring shell faces have inconsistent orientation";
            return false;
        }
        neighbors[a.face].emplace_back(b.face, flip);
        neighbors[b.face].emplace_back(a.face, flip);
    }
    const auto first = edges.begin()->second.front().face;
    std::vector<int> flips(shell.faces.size(), -1);
    flips[first] = 0;
    std::queue<std::size_t> queue;
    queue.push(first);
    std::size_t reached = 0;
    while (!queue.empty()) {
        const auto i = queue.front();
        queue.pop();
        ++reached;
        for (const auto& neighbor : neighbors[i]) {
            const int want = flips[i] ^ static_cast<int>(neighbor.second);
            if (flips[neighbor.first] < 0) {
                flips[neighbor.first] = want;
                queue.push(neighbor.first);
            } else if (flips[neighbor.first] != want) {
                error = "Shell is not orientable";
                return false;
            }
        }
    }
    if (reached != face_count) {
        error = "Footprint has multiple disconnected shells";
        return false;
    }
    for (std::size_t i = 0; i < shell.faces.size(); ++i)
        if (flips[i] == 1)
            std::reverse(shell.faces[i].begin(), shell.faces[i].end());

    const double volume = signed_volume(shell);
    if (!std::isfinite(volume) || std::abs(volume) <= minimum_volume) {
        error = "Shell has zero enclosed volume";
        return false;
    }
    if (volume < 0.0) {
        if (!repair_orientation) {
            error = "Shell normals face inward";
            return false;
        }
        for (auto& face : shell.faces)
            std::reverse(face.begin(), face.end());
    }
    return true;
}

bool validate_geometry(const Shell& shell, std::string& error) {
    std::vector<Ring> active;
    for (const auto& face : shell.faces)
        if (!face.empty())
            active.push_back(face);
    return WatertightValidation::validate(shell.vertices, active, error);
}

bool repair_low_roof(Shell& shell, const LowRoofRepair& input,
                     RoofClosureRepair::Result& report) {
    if (input.roof_faces.empty() || input.points.size() != input.normals.size())
        return false;

    std::vector<vec3> points, normals;
    points.reserve(input.point_indices.size());
    normals.reserve(input.point_indices.size());
    for (const auto index : input.point_indices) {
        if (index >= input.points.size())
            return false;
        points.push_back(input.points[index]);
        normals.push_back(input.normals[index]);
    }

    const std::size_t cap_face = shell.faces.size() - 1;
    if (!RoofClosureRepair::repair(shell.vertices, shell.faces, input.roof_faces,
                                  cap_face, points, normals, report))
        return false;

    std::string repair_error;
    return orient_shell(shell, false, repair_error) &&
        validate_geometry(shell, repair_error);
}

} // namespace

Map::Ptr stitch(Map* source, std::string& error, std::vector<Map::Facet*>* stitched_faces,
                LowRoofRepair* low_roof_repair) {
    error.clear();
    if (stitched_faces)
        stitched_faces->clear();
    if (low_roof_repair) {
        low_roof_repair->added_roof_faces.clear();
        low_roof_repair->support_points = 0;
        low_roof_repair->boundary_face_count = 0;
    }
    Shell raw;
    if (!read_shell(source, raw, error))
        return Map::Ptr();
    Shell shell;
    Shell failed_geometry;
    bool valid = false;
    for (const double tolerance : seam_tolerances) {
        shell = raw;
        weld_vertices(shell, tolerance);
        split_seam_edges(shell, tolerance);
        if (!orient_shell(shell, true, error))
            continue;
        if (validate_geometry(shell, error)) {
            valid = true;
            break;
        }
        if (low_roof_repair && failed_geometry.faces.empty())
            failed_geometry = std::move(shell);
    }
    RoofClosureRepair::Result repair_report;
    if (!valid && low_roof_repair && !failed_geometry.faces.empty() &&
        repair_low_roof(failed_geometry, *low_roof_repair, repair_report)) {
        shell = std::move(failed_geometry);
        for (const auto& added : repair_report.added_faces)
            shell.source_faces.push_back(shell.source_faces[added.second]);
        valid = true;
    }
    if (!valid)
        return Map::Ptr();
    error.clear();

    Map::Ptr result = new Map;
    MapFacetAttribute<Color> source_colors;
    source_colors.bind_if_defined(source, "color");
    MapFacetAttribute<Color> new_colors;
    if (source_colors.is_bound())
        new_colors.bind(result, "color");
    MapBuilder builder(result);
    builder.set_quiet(true);
    builder.begin_surface();
    for (const auto& vertex : shell.vertices)
        builder.add_vertex(vertex);
    std::vector<Map::Facet*> mapping(shell.faces.size(), nullptr);
    std::size_t expected_faces = 0;
    std::set<std::size_t> expected_vertices;
    for (std::size_t i = 0; i < shell.faces.size(); ++i) {
        if (shell.faces[i].empty())
            continue;
        ++expected_faces;
        builder.begin_facet();
        for (const auto vertex : shell.faces[i]) {
            builder.add_vertex_to_facet(static_cast<int>(vertex));
            expected_vertices.insert(vertex);
        }
        builder.end_facet();
        mapping[i] = builder.current_facet();
        if (new_colors.is_bound())
            new_colors[mapping[i]] = source_colors[shell.source_faces[i]];
    }
    builder.end_surface();
    if (result->size_of_facets() != expected_faces || result->size_of_vertices() != expected_vertices.size()) {
        error = "Mesh builder changed the validated shell connectivity";
        return Map::Ptr();
    }
    FOR_EACH_HALFEDGE(Map, result, it) {
        if (it->is_border()) {
            error = "Mesh builder left a border in the closed shell";
            return Map::Ptr();
        }
    }
    result->compute_facet_normals();
    if (stitched_faces)
        *stitched_faces = std::move(mapping);
    if (low_roof_repair) {
        for (const auto& added : repair_report.added_faces) {
            const auto& boundary = repair_report.boundary_faces;
            if (std::find(boundary.begin(), boundary.end(), added.first) == boundary.end())
                low_roof_repair->added_roof_faces.push_back(added.first);
        }
        low_roof_repair->support_points = repair_report.support_points;
        low_roof_repair->boundary_face_count = repair_report.boundary_faces.size();
    }
    return result;
}

bool validate(Map* source, std::string& error) {
    error.clear();
    Shell shell;
    return read_shell(source, shell, error) && orient_shell(shell, false, error) && validate_geometry(shell, error);
}

} // namespace WatertightMesh
