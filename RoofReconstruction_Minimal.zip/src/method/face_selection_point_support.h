#pragma once

#include "face_selection_scores.h"
#include "../math/polygon2d.h"
#include "../model/map_geometry.h"
#include "../model/point_set.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <set>
#include <tuple>
#include <utility>

namespace FaceSelectionPointSupport {

constexpr double distance_tolerance = 0.10;
constexpr double squared_tolerance = distance_tolerance * distance_tolerance;

inline std::vector<vec3> evaluation_points(const PointSet& points, const Polygon2d& footprint) {
    std::set<std::tuple<double, double, double>> unique;
    std::vector<vec3> evaluation;
    for (const VertexGroup::Ptr& group : points.groups())
        for (const unsigned int index : *group) {
            const vec3& point = points.points()[index];
            if (Geom::point_is_in_polygon(footprint, vec2(point.x, point.y)) &&
                unique.emplace(point.x, point.y, point.z).second)
                evaluation.push_back(point);
        }
    return evaluation;
}

struct RoofGeometry {
    Polygon3d vertices;
    Polygon2d projection;
    Polygon2d plane_polygon;
    Box2d projection_bounds;
    Box3d bounds;
    const Plane3d* plane;
    vec3 origin;
    vec3 basis_x;
    vec3 basis_y;

    explicit RoofGeometry(const FaceSelectionScores::Facet& facet)
        : RoofGeometry(Geom::facet_polygon(facet.face), *facet.plane) {}

    RoofGeometry(Polygon3d polygon, const Plane3d& supporting_plane)
        : vertices(std::move(polygon)), plane(&supporting_plane),
          origin(plane->point()), basis_x(plane->base1()), basis_y(plane->base2()) {
        for (const vec3& vertex : vertices) {
            const vec2 xy(vertex.x, vertex.y);
            projection.push_back(xy);
            projection_bounds.add_point(xy);
            bounds.add_point(vertex);
            plane_polygon.push_back(Geom::to_2d(origin, basis_x, basis_y, vertex));
        }
    }

    double squared_distance(const vec3& point, double best) const {
        const double plane_distance = plane->squared_ditance(point);
        if (plane_distance >= best)
            return best;

        const vec2 local = Geom::to_2d(origin, basis_x, basis_y, point);
        if (Geom::point_is_in_polygon(plane_polygon, local))
            return plane_distance;

        for (std::size_t i = 0; i < vertices.size(); ++i) {
            const vec3& a = vertices[i];
            const vec3 direction = vertices[(i + 1) % vertices.size()] - a;
            const double squared_length = length2(direction);
            const double t = squared_length > 0.0
                ? std::max(0.0, std::min(1.0, dot(point - a, direction) / squared_length)) : 0.0;
            best = std::min(best, length2(point - (a + t * direction)));
        }
        return best;
    }

    bool supports(const vec3& point, double radius = distance_tolerance) const {
        if (!bounds.initialized())
            return false;

        // Pad the pruning box for coordinate roundoff at its boundary. The
        // final finite-face distance comparison uses the original tolerance.
        const double margin = radius + 1e-8;
        if (point.x < bounds.x_min() - margin || point.x > bounds.x_max() + margin ||
            point.y < bounds.y_min() - margin || point.y > bounds.y_max() + margin ||
            point.z < bounds.z_min() - margin || point.z > bounds.z_max() + margin)
            return false;

        // A clipped distance equal to this bound is distinguishable from a
        // point whose actual distance is exactly the inclusive tolerance.
        const double squared_radius = radius * radius;
        const double limit = std::nextafter(squared_radius, std::numeric_limits<double>::infinity());
        return squared_distance(point, limit) <= squared_radius;
    }
};

struct Group {
    std::vector<std::size_t> facets;
    std::size_t point_count;
};

struct Result {
    std::size_t point_count;
    std::vector<Group> groups;
};

inline Result compute(const std::vector<vec3>& points,
                      const std::vector<FaceSelectionScores::Facet>& facets,
                      double radius = distance_tolerance) {
    Result result{points.size(), {}};
    if (points.empty())
        return result;

    std::vector<std::size_t> indices;
    std::vector<RoofGeometry> roofs;
    indices.reserve(facets.size());
    roofs.reserve(facets.size());
    for (std::size_t i = 0; i < facets.size(); ++i) {
        if (facets[i].roof && facets[i].face && facets[i].plane) {
            indices.push_back(i);
            roofs.emplace_back(facets[i]);
        }
    }

    // Points with the same set of supporting candidate IDs share one ILP
    // variable. Uncovered points still count in the fixed denominator.
    std::map<std::vector<std::size_t>, std::size_t> multiplicities;
    std::vector<std::size_t> supporting_facets;
    for (const vec3& point : points) {
        supporting_facets.clear();
        for (std::size_t i = 0; i < roofs.size(); ++i)
            if (roofs[i].supports(point, radius))
                supporting_facets.push_back(indices[i]);
        if (!supporting_facets.empty())
            ++multiplicities[supporting_facets];
    }

    result.groups.reserve(multiplicities.size());
    for (const auto& group : multiplicities)
        result.groups.push_back({group.first, group.second});
    return result;
}

} // namespace FaceSelectionPointSupport
