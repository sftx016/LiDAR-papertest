#pragma once

#include "face_selection_scores.h"

#include <cstddef>
#include <limits>
#include <vector>

namespace RoofFitRefinement {

struct Result {
	double offset = 0.0;
	double p95_before = std::numeric_limits<double>::quiet_NaN();
	double p95_after = std::numeric_limits<double>::quiet_NaN();
	std::size_t point_count = 0;
	std::size_t near_before = 0;
	std::size_t near_after = 0;
};

// Propose one vertical offset for the entire selected roof. Distances are
// measured on the existing finite roof polygons against fixed input points.
Result vertical_offset(const std::vector<FaceSelectionScores::Facet>& facets,
	const std::vector<std::size_t>& selected_roofs, const std::vector<vec3>& points,
	double floor_z, bool allow_offset = true);

} // namespace RoofFitRefinement
