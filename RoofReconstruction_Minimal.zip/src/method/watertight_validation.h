#pragma once

#include "../math/math_types.h"

#include <cstddef>
#include <string>
#include <vector>

namespace WatertightValidation {

// Test stitched and oriented face rings as one closed shell.
bool validate(const std::vector<vec3>& vertices,
              const std::vector<std::vector<std::size_t>>& faces,
              std::string& error);

} // namespace WatertightValidation
