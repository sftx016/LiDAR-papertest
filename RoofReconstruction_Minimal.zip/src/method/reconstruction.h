#pragma once



#include "../model/vertex_group.h"
#include "../model/map.h"
#include "../model/point_set.h"
#include "../math/linear_program_solver.h"
#include "face_selection.h"
#include <iosfwd>
#include <vector>


#include <RansacShapeDetector.h>
#include <PlanePrimitiveShapeConstructor.h>
#include <PlanePrimitiveShape.h>



class PolyFitInfo;

struct FaceSelectionOptions {
    FaceSelectionMode mode = FaceSelectionMode::Legacy;
    // When set, evaluate all selection modes and write one CSV row per mode.
    std::ostream* comparison_csv = nullptr;
    bool refine_selection = false;
    std::ostream* refinement_baseline_csv = nullptr;
    Map* refinement_baseline_model = nullptr;
};

class Reconstruction
{
 public:
	Reconstruction() {}
	~Reconstruction() {}

    /// segment the scene point cloud using footprint (to obtain individual buildings)
	void segmentation(PointSet* pset, Map* foot_print);

    /// extract the roof planes for each building
	void extract_roofs(PointSet* pset, Map* foot_print);

    /// generate the footprint for single building
    Map *generate_polygon(PointSet *pSet, double footprint_height=-5.97,double denisty=0.2);

	/// reconstruct mesh models of the buildings in the scene.
	/// Note: the reconstructed models will be merged into 'result'.
	bool reconstruct(PointSet* pset, Map* foot_print, Map* result, LinearProgramSolver::SolverName solver_name,
	                 bool update_display = false, const FaceSelectionOptions& options = FaceSelectionOptions());

 private:

    std::vector<std::vector<int>> detect_height_jump(PointSet* pset,
                                                     Map::Facet* footprint,
                                                     double min_height,
                                                     double max_height);

    std::vector<std::vector<int>> compute_height_field(PointSet* pset, Map::Facet* footprint);

    PointSet* create_roof_point_set(const PointSet* pset,
		const std::vector<VertexGroup::Ptr>& segments, VertexGroup* building);

	PointSet* create_projected_point_set(const PointSet* roof);

	void extract_building_roof(PointSet* pset,
		VertexGroup* building,
		unsigned int min_support = 50);

	Map::Ptr reconstruct_single_building(PointSet* roof_pset, const PointSet& scene_points,
	                                    const VertexGroup& footprint_points,
	                                    std::vector<vec3> line_segments, Map::Facet* footprint,
	                                    LinearProgramSolver::SolverName solver_name, const FaceSelectionOptions& options,
	                                    std::size_t building_id);

	std::vector<vec3> compute_line_segment(PointSet* seg_pset, PointSet* roof_pset, Map::Facet* footprint);
	std::vector<vec3> compute_line_segment2(PointSet* seg_pset, PointSet* roof_pset, Map::Facet* footprint);

	void extrude_boundary_to_ground(Map* model, const Plane3d& ground, PolyFitInfo* polyfit_info);

	int width = 400, height = 400;


};

