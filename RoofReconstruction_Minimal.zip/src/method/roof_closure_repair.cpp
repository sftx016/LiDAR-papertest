#include "roof_closure_repair.h"

#include "face_selection_point_support.h"
#include "roof_closure_evidence.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <set>

namespace RoofClosureRepair {
namespace {

constexpr double height_tolerance = 1e-8;
// A centimeter of clearance keeps the taper above the cap at all seam tolerances.
constexpr double taper_clearance = 0.01;
constexpr double max_taper_area = 1.0;
constexpr double max_taper_fraction = 0.01;

using Ring = std::vector<std::size_t>;
using Edge = std::pair<std::size_t, std::size_t>;

bool valid_ring(const Ring& ring, const std::vector<vec3>& vertices)
{
    if (ring.size() < 3)
        return false;
    std::set<std::size_t> used;
    for (const auto index : ring) {
        if (index >= vertices.size() || !used.insert(index).second)
            return false;
        const auto& p = vertices[index];
        if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z))
            return false;
    }
    return true;
}

struct CutVertex {
    std::size_t index;
    std::size_t wall_uses = 0;
};

using Cuts = std::map<Edge, CutVertex>;

bool split_roof(const Ring& roof, const std::vector<vec3>& input,
                const std::vector<std::size_t>& roof_uses, const std::set<std::size_t>& cap_vertices,
                double height, std::vector<vec3>& vertices, Cuts& cuts, Ring& high, Ring& low)
{
    std::size_t crossings = 0;
    for (std::size_t i = 0; i < roof.size(); ++i) {
        const auto a = roof[i];
        const auto b = roof[(i + 1) % roof.size()];
        const double az = input[a].z - height;
        const double bz = input[b].z - height;
        if (std::abs(az) <= height_tolerance)
            return false; // A cut through an existing corner needs separate treatment.
        if (az < 0.0) {
            if (roof_uses[a] != 1 || cap_vertices.count(a))
                return false;
            vertices[a].z = height;
            low.push_back(a);
        } else {
            high.push_back(a);
        }
        if ((az < 0.0) == (bz < 0.0))
            continue;
        const auto index = vertices.size();
        if (!cuts.emplace(std::minmax(a, b), CutVertex{index}).second)
            return false;
        const double t = -az / (bz - az);
        const auto& p = input[a];
        const auto& q = input[b];
        vertices.emplace_back(p.x + t * (q.x - p.x), p.y + t * (q.y - p.y), height);
        low.push_back(index);
        high.push_back(index);
        ++crossings;
    }
    // A single cutting chord must divide the projected roof into two pieces.
    return crossings == 2 && low.size() >= 3 && high.size() >= 3;
}

double projected_area(const Ring& ring, const std::vector<vec3>& vertices)
{
    const auto& origin = vertices[ring.front()];
    double twice_area = 0.0;
    for (std::size_t i = 1; i + 1 < ring.size(); ++i)
        twice_area += cross(vertices[ring[i]] - origin, vertices[ring[i + 1]] - origin).z;
    return 0.5 * std::abs(twice_area);
}

bool has_point_support(const Polygon3d& polygon, const std::vector<vec3>& points)
{
    const auto& origin = polygon.front();
    vec3 normal(0.0, 0.0, 0.0);
    for (std::size_t i = 1; i + 1 < polygon.size(); ++i)
        normal += cross(polygon[i] - origin, polygon[i + 1] - origin);
    if (!(length2(normal) > 1e-28))
        return true;
    Polygon3d local;
    local.reserve(polygon.size());
    for (const auto& vertex : polygon)
        local.push_back(vertex - origin);
    const Plane3d plane(vec3(0.0, 0.0, 0.0), normal);
    const FaceSelectionPointSupport::RoofGeometry geometry(std::move(local), plane);
    return std::any_of(points.begin(), points.end(), [&](const vec3& point) {
        return std::isfinite(point.x) && std::isfinite(point.y) && std::isfinite(point.z) &&
            geometry.supports(point - origin);
    });
}

bool taper_boundary(const Ring& low, const std::vector<vec3>& original,
                    const std::vector<vec3>& points, double ground, double cut,
                    std::vector<vec3>& vertices)
{
    Polygon3d old_fragment, taper;
    old_fragment.reserve(low.size());
    taper.reserve(low.size());
    double lowest = cut;
    for (const auto index : low) {
        const auto& vertex = index < original.size() ? original[index] : vertices[index];
        lowest = std::min(lowest, vertex.z);
        old_fragment.push_back(vertex);
    }
    if (has_point_support(old_fragment, points))
        return false;
    for (const auto index : low) {
        if (index < original.size()) {
            const double t = (original[index].z - lowest) / (cut - lowest);
            vertices[index].z = ground + taper_clearance + taper_clearance * t;
        }
        taper.push_back(vertices[index]);
    }
    return !has_point_support(taper, points);
}

} // namespace

bool repair(std::vector<vec3>& vertices, std::vector<Ring>& faces,
            const std::vector<std::size_t>& roof_faces, std::size_t cap_face,
            const std::vector<vec3>& points, const std::vector<vec3>& normals,
            Result& result)
{
    if (cap_face >= faces.size() || !valid_ring(faces[cap_face], vertices))
        return false;
    const Ring& cap = faces[cap_face];
    const double ground = vertices[cap.front()].z;
    if (std::any_of(cap.begin(), cap.end(), [&](const auto index) {
            return std::abs(vertices[index].z - ground) > height_tolerance;
        }))
        return false;
    const std::set<std::size_t> cap_vertices(cap.begin(), cap.end());

    std::set<std::size_t> roof_indices;
    std::vector<std::size_t> roof_uses(vertices.size(), 0);
    std::vector<std::size_t> affected;
    for (const auto index : roof_faces) {
        if (index >= faces.size() || index == cap_face || !roof_indices.insert(index).second)
            return false;
        const Ring& ring = faces[index];
        if (ring.empty())
            continue;
        if (!valid_ring(ring, vertices))
            return false;
        bool underflow = false;
        for (const auto vertex : ring) {
            ++roof_uses[vertex];
            underflow = underflow || vertices[vertex].z < ground - height_tolerance;
        }
        if (underflow)
            affected.push_back(index);
    }
    if (affected.empty())
        return false;

    auto repaired_vertices = vertices;
    auto repaired_faces = faces;
    Result patch;
    Cuts cuts;
    const double taper_area_limit = std::min(max_taper_area, max_taper_fraction * projected_area(cap, vertices));
    double taper_area = 0.0;
    for (const auto face : affected) {
        const Ring& ring = faces[face];
        std::vector<vec3> roof;
        roof.reserve(ring.size());
        for (const auto index : ring)
            roof.push_back(vertices[index]);
        LowPlaneEvidence evidence;
        const bool measured = find_low_plane(roof, ground, points, normals, evidence);
        const double cut = measured ? evidence.z : ground + 2.0 * taper_clearance;
        if (!std::isfinite(cut) || cut <= ground + height_tolerance ||
            (measured && evidence.support == 0) || points.empty())
            return false;
        Ring high, low;
        if (!split_roof(ring, vertices, roof_uses, cap_vertices, cut, repaired_vertices, cuts, high, low))
            return false;
        if (!measured) {
            const double area = projected_area(low, repaired_vertices);
            taper_area += area;
            if (!(area > 0.0 && taper_area <= taper_area_limit) ||
                !taper_boundary(low, vertices, points, ground, cut, repaired_vertices))
                return false;
            patch.boundary_faces.push_back(repaired_faces.size());
        }
        repaired_faces[face] = std::move(high);
        patch.added_faces.emplace_back(repaired_faces.size(), face);
        repaired_faces.push_back(std::move(low));
        patch.support_points += evidence.support;
    }

    for (std::size_t face = 0; face < faces.size(); ++face) {
        if (roof_indices.count(face) || face == cap_face || faces[face].empty())
            continue;
        const Ring& ring = faces[face];
        if (!valid_ring(ring, vertices))
            return false;
        Ring wall;
        for (std::size_t i = 0; i < ring.size(); ++i) {
            const auto a = ring[i];
            const auto b = ring[(i + 1) % ring.size()];
            wall.push_back(a);
            const auto cut = cuts.find(std::minmax(a, b));
            if (cut != cuts.end()) {
                wall.push_back(cut->second.index);
                ++cut->second.wall_uses;
            }
        }
        repaired_faces[face] = std::move(wall);
    }
    if (std::any_of(cuts.begin(), cuts.end(), [](const auto& cut) { return cut.second.wall_uses != 1; }))
        return false;

    vertices = std::move(repaired_vertices);
    faces = std::move(repaired_faces);
    result = std::move(patch);
    return true;
}

} // namespace RoofClosureRepair
