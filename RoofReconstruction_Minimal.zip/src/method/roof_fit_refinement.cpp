#include "roof_fit_refinement.h"

#include "face_selection_point_support.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace RoofFitRefinement {
namespace {

using FaceSelectionPointSupport::RoofGeometry;

constexpr double offset_step = 0.005;
constexpr int offset_steps = 8;
constexpr double floor_clearance = 1e-4;
constexpr double fit_tolerance = 1e-8;

struct Fit {
	double p95;
	std::size_t near_count;
};

Fit measure(const std::vector<RoofGeometry>& roofs, const std::vector<vec3>& points,
	double offset, std::vector<double>& residuals)
{
	std::size_t near_count = 0;
	for (std::size_t i = 0; i < points.size(); ++i)
	{
		// Translating the query point in the opposite direction is equivalent
		// to translating every finite roof polygon and its plane.
		const vec3 query(points[i].x, points[i].y, points[i].z - offset);
		double best = std::numeric_limits<double>::infinity();
		for (const auto& roof : roofs)
			best = roof.squared_distance(query, best);
		residuals[i] = best;
		near_count += best <= FaceSelectionPointSupport::squared_tolerance;
	}

	const std::size_t rank = (95 * residuals.size() - 1) / 100;
	const auto percentile = residuals.begin() + rank;
	std::nth_element(residuals.begin(), percentile, residuals.end());
	return Fit{std::sqrt(*percentile), near_count};
}

} // namespace

Result vertical_offset(const std::vector<FaceSelectionScores::Facet>& facets,
	const std::vector<std::size_t>& selected_roofs, const std::vector<vec3>& points,
	double floor_z, bool allow_offset)
{
	Result result;
	result.point_count = points.size();
	if (points.empty() || selected_roofs.empty() || !std::isfinite(floor_z))
		return result;

	std::vector<RoofGeometry> roofs;
	roofs.reserve(selected_roofs.size());
	double lowest_roof = std::numeric_limits<double>::infinity();
	for (const std::size_t id : selected_roofs)
	{
		if (id >= facets.size() || !facets[id].roof || !facets[id].face || !facets[id].plane)
			return result;
		roofs.emplace_back(facets[id]);
		if (roofs.back().vertices.size() < 3)
			return result;
		lowest_roof = std::min(lowest_roof, roofs.back().bounds.z_min());
	}

	std::vector<double> residuals(points.size());
	const Fit baseline = measure(roofs, points, 0.0, residuals);
	result.p95_before = result.p95_after = baseline.p95;
	result.near_before = result.near_after = baseline.near_count;
	if (!allow_offset || !std::isfinite(baseline.p95) || lowest_roof <= floor_z + floor_clearance)
		return result;

	for (int step = 1; step <= offset_steps; ++step)
	{
		for (const int direction : {-1, 1})
		{
			const double offset = direction * step * offset_step;
			if (lowest_roof + offset <= floor_z + floor_clearance)
				continue;
			const Fit fit = measure(roofs, points, offset, residuals);
			const bool improves = fit.p95 < result.p95_after - fit_tolerance;
			const bool equally_good = std::abs(fit.p95 - result.p95_after) <= fit_tolerance;
			if (fit.near_count < baseline.near_count || !(fit.p95 < baseline.p95 - fit_tolerance) ||
				!(improves || (equally_good && fit.near_count > result.near_after)))
				continue;
			result.offset = offset;
			result.p95_after = fit.p95;
			result.near_after = fit.near_count;
		}
	}
	return result;
}

} // namespace RoofFitRefinement
