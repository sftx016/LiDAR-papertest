#pragma once

#include "../model/map.h"

#include <cstddef>
#include <utility>
#include <vector>

class PointSet;
class VertexGroup;

namespace FaceSelectionScores {

struct Facet {
    Map::Facet* face;
    VertexGroup* group;
    Plane3d* plane;
    bool roof;
};

struct Edge {
    vec3 a, b;
    std::vector<std::size_t> facets;
};

struct Ridge {
    std::size_t first, second, edge;
    double reward;
};

struct Boundary {
    std::vector<std::size_t> facets;
    double reward;
};

struct Result {
    std::vector<double> support, area_penalty;
    std::vector<double> coverage, xy_area;
    std::vector<Ridge> ridges;
    std::vector<Boundary> boundary;
};

Result compute(PointSet* pset, Map::Facet* footprint, const std::vector<Facet>& facets,
               const std::vector<Edge>& edges, bool full);

// Candidate indices whose XY projections share positive area inside the footprint.
std::vector<std::pair<std::size_t, std::size_t>> overlapping_roofs(
    Map::Facet* footprint, const std::vector<Facet>& facets);

} // namespace FaceSelectionScores
