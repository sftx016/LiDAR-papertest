#include "roof_closure_evidence.h"

#include "../math/polygon2d.h"

#include <algorithm>
#include <cmath>

namespace RoofClosureRepair {
namespace {

constexpr double height_band = 0.10;
constexpr double minimum_surface_difference = 0.20;
constexpr double minimum_normal_alignment_squared = 0.8830222216; // cos squared of 20 degrees
constexpr double minimum_support_spread = 0.15;
constexpr std::size_t minimum_support = 20;
constexpr std::size_t minimum_below_ground_support = 6;

struct Sample {
    vec2 position;
    double z;
    bool in_crossing_region;
};

bool is_finite(const vec3& p)
{
    return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
}

} // namespace

bool find_low_plane(const std::vector<vec3>& roof, double ground_z,
                    const std::vector<vec3>& points, const std::vector<vec3>& normals,
                    LowPlaneEvidence& evidence)
{
    evidence = LowPlaneEvidence();
    if (roof.size() < 3 || points.size() < minimum_support || normals.size() != points.size() ||
        !std::isfinite(ground_z))
        return false;

    const vec3& origin = roof.front();
    Polygon2d footprint;
    footprint.reserve(roof.size());
    vec3 normal(0.0, 0.0, 0.0);
    double low = origin.z;
    double high = origin.z;
    for (std::size_t i = 0; i < roof.size(); ++i) {
        const vec3& vertex = roof[i];
        if (!is_finite(vertex))
            return false;
        const vec3 p = vertex - origin;
        normal += cross(p, roof[(i + 1) % roof.size()] - origin);
        footprint.emplace_back(p.x, p.y);
        low = std::min(low, vertex.z);
        high = std::max(high, vertex.z);
    }
    if (low >= ground_z || high <= ground_z + 2 * minimum_surface_difference ||
        std::abs(normal.z) <= 1e-12)
        return false;

    normal /= length(normal);
    if (normal.z < 0.0)
        normal = -normal;

    std::vector<Sample> samples;
    for (std::size_t i = 0; i < points.size(); ++i) {
        const vec3& point = points[i];
        const vec3& point_normal = normals[i];
        const double normal_squared = length2(point_normal);
        if (!is_finite(point) || !is_finite(point_normal) || normal_squared <= 1e-12 ||
            point_normal.z * point_normal.z < minimum_normal_alignment_squared * normal_squared ||
            point.z <= ground_z + minimum_surface_difference ||
            point.z >= high - minimum_surface_difference)
            continue;
        const vec3 p = point - origin;
        // A horizontal replacement can only help where points lie above the
        // selected plane. Require a material decrease in point-plane distance.
        if (dot(normal, p) < minimum_surface_difference)
            continue;
        const vec2 position(p.x, p.y);
        if (Geom::point_is_in_polygon(footprint, position)) {
            const double ground_side = normal.x * p.x + normal.y * p.y + normal.z * (ground_z - origin.z);
            samples.push_back(Sample{position, point.z, ground_side > 0.0});
        }
    }
    if (samples.size() < minimum_support)
        return false;

    std::sort(samples.begin(), samples.end(), [](const Sample& a, const Sample& b) { return a.z < b.z; });
    // The height band must have support in the part of the selected roof that
    // lies below the ground, as well as nearby in the face.
    std::size_t start = 0;
    std::size_t end = 0;
    std::size_t first = 0;
    std::size_t anchored = 0;
    for (std::size_t i = 0; i < samples.size(); ++i) {
        anchored += samples[i].in_crossing_region;
        while (samples[i].z - samples[first].z > height_band) {
            anchored -= samples[first].in_crossing_region;
            ++first;
        }
        if (anchored >= minimum_below_ground_support && i + 1 - first > end - start) {
            start = first;
            end = i + 1;
        }
    }
    const std::size_t count = end - start;
    if (count < minimum_support)
        return false;

    // Returns confined to a narrow strip do not establish a surface.
    vec2 center(0.0, 0.0);
    for (std::size_t i = start; i < end; ++i)
        center += samples[i].position;
    center /= static_cast<double>(count);

    double xx = 0.0, xy = 0.0, yy = 0.0;
    for (std::size_t i = start; i < end; ++i) {
        const vec2 p = samples[i].position - center;
        xx += p.x * p.x;
        xy += p.x * p.y;
        yy += p.y * p.y;
    }
    const double transverse_variance = (xx + yy - std::hypot(xx - yy, 2 * xy)) / (2 * count);
    if (transverse_variance < minimum_support_spread * minimum_support_spread)
        return false;

    evidence.z = (samples[start + (count - 1) / 2].z + samples[start + count / 2].z) / 2;
    evidence.support = count;
    return true;
}

} // namespace RoofClosureRepair
