#include "watertight_validation.h"

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_mesh_processing/self_intersections.h>
#include <CGAL/Polygon_mesh_processing/triangulate_faces.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/boost/graph/helpers.h>

#include <cmath>
#include <exception>
#include <iterator>
#include <utility>

namespace WatertightValidation {
namespace {

using Kernel = CGAL::Exact_predicates_inexact_constructions_kernel;
using Mesh = CGAL::Surface_mesh<Kernel::Point_3>;
using Face = Mesh::Face_index;
namespace PMP = CGAL::Polygon_mesh_processing;

constexpr double planarity_tolerance = 2e-4;

bool validate_ring(const std::vector<vec3>& vertices, const std::vector<std::size_t>& ring)
{
    const vec3& origin = vertices[ring.front()];
    vec3 normal(0.0, 0.0, 0.0);
    for (std::size_t i = 1; i + 1 < ring.size(); ++i)
        normal += cross(vertices[ring[i]] - origin, vertices[ring[i + 1]] - origin);
    const double magnitude = length(normal);
    if (!(magnitude > 1e-14))
        return false;

    unsigned int drop = 0;
    for (unsigned int axis = 1; axis != 3; ++axis)
        if (std::abs(normal[axis]) > std::abs(normal[drop]))
            drop = axis;

    // Points snapped along seams can have small offsets off their original plane.
    CGAL::Polygon_2<Kernel> projection;
    for (std::size_t index : ring) {
        const vec3 offset = vertices[index] - origin;
        if (std::abs(dot(normal, offset)) > planarity_tolerance * magnitude)
            return false;
        projection.push_back(Kernel::Point_2(offset[(drop + 1) % 3], offset[(drop + 2) % 3]));
    }
    return projection.is_simple();
}

// Preserve the input ring index for all triangles produced from that ring.
struct RingIndexVisitor : PMP::Triangulate_faces::Default_visitor<Mesh> {
    Mesh::Property_map<Face, std::size_t> ring_index;
    std::size_t current = 0;

    explicit RingIndexVisitor(Mesh::Property_map<Face, std::size_t> index) : ring_index(index) {}
    void before_subface_creations(Face face) { current = ring_index[face]; }
    void after_subface_created(Face face) { ring_index[face] = current; }
};

} // namespace

bool validate(const std::vector<vec3>& vertices,
              const std::vector<std::vector<std::size_t>>& faces,
              std::string& error)
{
    error.clear();
    if (vertices.empty() || faces.empty()) {
        error = "empty shell";
        return false;
    }

    try {
        Mesh mesh;
        std::vector<Mesh::Vertex_index> nodes;
        nodes.reserve(vertices.size());
        for (const vec3& vertex : vertices) {
            const vec3 point = vertex - vertices.front();
            if (!std::isfinite(point.x) || !std::isfinite(point.y) || !std::isfinite(point.z)) {
                error = "non-finite shell vertex";
                return false;
            }
            nodes.push_back(mesh.add_vertex(Kernel::Point_3(point.x, point.y, point.z)));
        }

        auto ring_index = mesh.add_property_map<Face, std::size_t>("f:source_ring").first;
        std::vector<Mesh::Vertex_index> boundary;
        for (std::size_t i = 0; i < faces.size(); ++i) {
            const auto& ring = faces[i];
            boundary.clear();
            for (std::size_t index : ring) {
                if (index >= nodes.size()) {
                    error = "invalid vertex index in shell ring " + std::to_string(i);
                    return false;
                }
                boundary.push_back(nodes[index]);
            }
            if (ring.size() < 3 || !validate_ring(vertices, ring)) {
                error = "degenerate, non-simple or non-planar shell ring " + std::to_string(i);
                return false;
            }
            const Face face = mesh.add_face(boundary);
            if (face == Mesh::null_face()) {
                error = "inconsistent topology at shell ring " + std::to_string(i);
                return false;
            }
            ring_index[face] = i;
        }

        if (!CGAL::is_closed(mesh) || !CGAL::is_valid_polygon_mesh(mesh)) {
            error = "invalid closed polygon shell";
            return false;
        }
        if (!PMP::triangulate_faces(mesh, CGAL::parameters::visitor(RingIndexVisitor(ring_index))) ||
            !CGAL::is_triangle_mesh(mesh) || !CGAL::is_valid_polygon_mesh(mesh) || !CGAL::is_closed(mesh)) {
            error = "unable to triangulate the closed shell for intersection checks";
            return false;
        }

        std::vector<std::pair<Face, Face>> intersections;
        PMP::self_intersections(mesh, std::back_inserter(intersections), CGAL::parameters::maximum_number(1));
        if (!intersections.empty()) {
            const auto& hit = intersections.front();
            error = hit.first == hit.second
                ? "degenerate shell triangle in ring " + std::to_string(ring_index[hit.first])
                : "self-intersection between shell rings " + std::to_string(ring_index[hit.first]) +
                      " and " + std::to_string(ring_index[hit.second]);
            return false;
        }
    } catch (const std::exception& exception) {
        error = std::string("shell validation failed: ") + exception.what();
        return false;
    }

    return true;
}

} // namespace WatertightValidation
