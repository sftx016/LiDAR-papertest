/*
Copyright (C) 2017  Liangliang Nan
https://3d.bk.tudelft.nl/liangliang/ - liangliang.nan@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "face_selection.h"
#include "face_selection_scores.h"
#include "face_selection_point_support.h"
#include "polyfit_info.h"
#include "method_global.h"
#include "../model/point_set.h"
#include "../model/map_editor.h"
#include "../model/map_geometry.h"
#include "../model/map_circulators.h"
#include "../basic/logger.h"
#include "../math/polygon2d.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <tuple>
#include <utility>

std::vector<Map::Facet*> FaceSelection::overlapping_faces(Map::Facet* f,
	const std::vector<Map::Facet*>& faces,
	Map::Facet* footprint)
{
	vec3 c(0, 0, 0);
	int degree = 0;

	FacetHalfedgeCirculator cir(f);
	for (; !cir->end(); ++cir)
	{
		c += cir->halfedge()->vertex()->point();
		++degree;
	}
	c /= degree;

	const Plane3d& plane = Geom::facet_plane(footprint);
	c = plane.projection(c);
	const vec2& p = plane.to_2d(c);

	std::vector<Map::Facet*> roofs({ f });

	for (std::size_t i = 0; i < faces.size(); ++i)
	{
		Map::Facet* face = faces[i];
		if (f == face)
			continue;

		Polygon2d plg;
		FacetHalfedgeCirculator fcir(face);
		for (; !fcir->end(); ++fcir)
		{
			vec3 q = fcir->halfedge()->vertex()->point();
			q = plane.projection(q);
			const vec2& r = plane.to_2d(q);
			plg.push_back(r);
		}
		if (Geom::point_is_in_polygon(plg, p))
			roofs.push_back(face);
	}

	return roofs;
}

std::vector<std::vector<Map::Facet*> > FaceSelection::find_multi_roofs(Map* mesh,
	Map::Facet* footprint,
	std::vector<Plane3d*>& v)
{
	facet_attrib_supporting_plane_.bind_if_defined(model_, "FacetSupportingPlane");
	std::vector<Map::Facet*> faces;
	FOR_EACH_FACET(Map, mesh, it)
	{
		int count = 0; //count the testing times
		for (std::size_t k = 0; k < v.size(); k++)
		{
			const Plane3d* ver = v[k];
			if (facet_attrib_supporting_plane_[it] == ver)
				break;
			count++;
		}
		if (count == v.size())
			faces.push_back(it);
	}
	std::vector<std::vector<Map::Facet*> > multiple_roofs;
	for (std::size_t i = 0; i < faces.size(); ++i)
	{
		Map::Facet* ft = faces[i];
		const std::vector<Map::Facet*>& roofs = overlapping_faces(ft, faces, footprint);
		if (roofs.size() > 1)
			multiple_roofs.push_back(roofs);
	}
	return multiple_roofs;
}


namespace {

using Program = LinearProgram<double>;
using Constraint = Program::Constraint;
using Objective = Program::Objective;

constexpr double data_weight = 1.0;
constexpr double curvature_weight = 0.45;
constexpr double boundary_weight = 0.30;
constexpr double area_weight = 0.25;

std::size_t binary_variable(Program& program)
{
	const std::size_t index = program.variables().size();
	program.add_variable(Program::Variable(Program::Variable::BINARY));
	return index;
}

void upper_bound(Program& program, Constraint constraint, double rhs)
{
	constraint.set_bounds(Constraint::UPPER, 0.0, rhs);
	program.add_constraint(constraint);
}

void lower_bound(Program& program, Constraint constraint, double rhs)
{
	constraint.set_bounds(Constraint::LOWER, rhs, 0.0);
	program.add_constraint(constraint);
}

void fix(Program& program, std::size_t variable, double value)
{
	Constraint constraint;
	constraint.add_coefficient(variable, 1.0);
	constraint.set_bounds(Constraint::FIXED, value, value);
	program.add_constraint(constraint);
}

void add_structure_scores(Program& program, Objective& objective,
	const FaceSelectionScores::Result& scores)
{
	std::map<std::size_t, std::vector<std::size_t>> ridge_variables;
	for (const auto& ridge : scores.ridges)
	{
		const std::size_t y = binary_variable(program);
		ridge_variables[ridge.edge].push_back(y);
		objective.add_coefficient(y, -curvature_weight * ridge.reward);

		for (const std::size_t facet : {ridge.first, ridge.second})
		{
			Constraint implication;
			implication.add_coefficient(y, 1.0);
			implication.add_coefficient(facet, -1.0);
			upper_bound(program, implication, 0.0);
		}
		Constraint pair_selected;
		pair_selected.add_coefficient(ridge.first, 1.0);
		pair_selected.add_coefficient(ridge.second, 1.0);
		pair_selected.add_coefficient(y, -1.0);
		upper_bound(program, pair_selected, 1.0);
	}
	for (const auto& edge : ridge_variables)
	{
		if (edge.second.size() < 2)
			continue;
		Constraint credit_once;
		for (const std::size_t variable : edge.second)
			credit_once.add_coefficient(variable, 1.0);
		upper_bound(program, credit_once, 1.0);
	}

	for (const auto& boundary : scores.boundary)
	{
		if (boundary.facets.empty())
			continue;
		const std::size_t z = binary_variable(program);
		objective.add_coefficient(z, -boundary_weight * boundary.reward);
		Constraint segment_covered;
		segment_covered.add_coefficient(z, 1.0);
		for (const std::size_t facet : boundary.facets)
		{
			segment_covered.add_coefficient(facet, -1.0);
			Constraint credit;
			credit.add_coefficient(facet, 1.0);
			credit.add_coefficient(z, -1.0);
			upper_bound(program, credit, 0.0);
		}
		upper_bound(program, segment_covered, 0.0);
	}
}

bool selected(const std::vector<double>& solution, std::size_t index)
{
	return solution[index] > 0.5;
}

using FaceSelectionPointSupport::RoofGeometry;

bool contains_projection(const RoofGeometry& roof, const vec2& xy)
{
	const Box2d& box = roof.projection_bounds;
	return xy.x >= box.x_min() && xy.x <= box.x_max() &&
		xy.y >= box.y_min() && xy.y <= box.y_max() &&
		Geom::point_is_in_polygon(roof.projection, xy);
}

Polygon2d footprint_polygon(Map::Facet* footprint)
{
	Polygon2d polygon;
	for (const vec3& vertex : Geom::facet_polygon(footprint))
		polygon.push_back(vec2(vertex.x, vertex.y));
	return polygon;
}

std::vector<vec2> footprint_samples(const Polygon2d& polygon)
{
	Box2d bounds;
	for (const vec2& xy : polygon)
		bounds.add_point(xy);
	const double width = bounds.x_max() - bounds.x_min();
	const double height = bounds.y_max() - bounds.y_min();
	std::vector<vec2> samples;
	if (width <= 0.0 || height <= 0.0)
		return samples;

	// A common grid for all solutions; the maximum side has 160 cells.
	const double step = std::max(width, height) / 160.0;
	const int nx = std::max(1, static_cast<int>(std::ceil(width / step)));
	const int ny = std::max(1, static_cast<int>(std::ceil(height / step)));
	for (int j = 0; j < ny; ++j)
		for (int i = 0; i < nx; ++i)
		{
			const vec2 xy(bounds.x_min() + (i + 0.5) * width / nx,
				bounds.y_min() + (j + 0.5) * height / ny);
			if (Geom::point_is_in_polygon(polygon, xy))
				samples.push_back(xy);
		}
	return samples;
}

void measure_roof(FaceSelectionReport& report, const std::vector<double>& solution,
	const std::vector<FaceSelectionScores::Facet>& facets,
	const std::vector<FaceSelectionScores::Edge>& edges,
	const std::vector<vec2>& samples, const std::vector<vec3>& points)
{
	std::vector<RoofGeometry> roofs;
	for (const std::size_t index : report.selected_roofs)
		roofs.emplace_back(facets[index]);

	std::size_t covered = 0;
	std::size_t overlapping = 0;
	for (const vec2& xy : samples)
	{
		std::size_t count = 0;
		for (const RoofGeometry& roof : roofs)
		{
			if (contains_projection(roof, xy))
				++count;
			if (count > 1)
				break;
		}
		covered += count > 0;
		overlapping += count > 1;
	}
	if (!samples.empty())
	{
		report.roof_coverage = static_cast<double>(covered) / samples.size();
		report.roof_overlap = static_cast<double>(overlapping) / samples.size();
	}

	// Single-face edges along the footprint are expected before wall extrusion.
	for (const auto& edge : edges)
	{
		if (edge.facets.size() < 2)
			continue;
		std::size_t incident = 0;
		bool has_roof = false;
		for (const std::size_t index : edge.facets)
			if (selected(solution, index))
			{
				++incident;
				has_roof = has_roof || facets[index].roof;
			}
		report.open_roof_edges += has_roof && incident == 1;
	}

	report.roof_fit_p95 = std::numeric_limits<double>::quiet_NaN();
	if (roofs.empty() || points.empty())
		return;
	std::vector<double> residuals;
	residuals.reserve(points.size());
	std::size_t fitted = 0;
	for (const vec3& point : points)
	{
		double best = std::numeric_limits<double>::infinity();
		for (const auto& roof : roofs)
			best = roof.squared_distance(point, best);
		residuals.push_back(best);
		fitted += best <= FaceSelectionPointSupport::squared_tolerance;
	}
	const std::size_t rank = (95 * residuals.size() - 1) / 100;
	std::nth_element(residuals.begin(), residuals.begin() + rank, residuals.end());
	report.roof_fit_p95 = std::sqrt(residuals[rank]);
	report.roof_point_coverage = static_cast<double>(fitted) / points.size();
}


struct RoofSelection {
	FaceSelectionReport report;
	std::vector<double> values;

	bool has_roof() const { return !report.selected_roofs.empty(); }
};

std::vector<double> solve(Program& program, LinearProgramSolver::SolverName name)
{
	LinearProgramSolver solver;
	if (!solver.solve(&program, name) || solver.get_result().size() != program.variables().size())
		return {};
	return solver.get_result();
}

using RoofConflicts = std::vector<std::pair<std::size_t, std::size_t>>;

bool meets_overlap_constraints(const std::vector<double>& selection, const RoofConflicts& conflicts)
{
	for (const auto& pair : conflicts)
		if (selected(selection, pair.first) && selected(selection, pair.second))
			return false;
	return true;
}

void require_single_layer(Program& program, const RoofConflicts& conflicts)
{
	for (const auto& pair : conflicts)
	{
		Constraint exclusive;
		exclusive.add_coefficient(pair.first, 1.0);
		exclusive.add_coefficient(pair.second, 1.0);
		upper_bound(program, exclusive, 1.0);
	}
}

std::size_t count_point_support(const FaceSelectionPointSupport::Result& support,
	const std::vector<double>& selection)
{
	std::size_t count = 0;
	for (const auto& group : support.groups)
		if (std::any_of(group.facets.begin(), group.facets.end(),
			[&selection](std::size_t index) { return selected(selection, index); }))
			count += group.point_count;
	return count;
}

double objective_value(const Objective& objective, const std::vector<double>& result)
{
	double value = 0.0;
	for (const auto& term : objective.coefficients())
		if (selected(result, term.first))
			value += term.second;
	return value;
}

std::size_t support_indicator(Program& program, const std::vector<std::size_t>& facets)
{
	const std::size_t used = binary_variable(program);
	Constraint has_supporting_face;
	has_supporting_face.add_coefficient(used, 1.0);
	for (const auto index : facets)
		has_supporting_face.add_coefficient(index, -1.0);
	upper_bound(program, has_supporting_face, 0.0);
	return used;
}

std::vector<double> solve_with_support_floor(Program program,
	const FaceSelectionPointSupport::Result& support, std::size_t floor,
	LinearProgramSolver::SolverName solver)
{
	if (support.groups.empty())
		return solve(program, solver);

	const Objective primary = program.objective();
	Constraint minimum_support;
	Objective prefer_support;
	// One indicator counts all points with the same set of compatible faces.
	for (const auto& group : support.groups)
	{
		const std::size_t used = support_indicator(program, group.facets);
		minimum_support.add_coefficient(used, static_cast<double>(group.point_count));
		prefer_support.add_coefficient(used, -static_cast<double>(group.point_count) / support.point_count);
	}
	if (floor > 0)
		lower_bound(program, minimum_support, static_cast<double>(floor));

	auto initial = solve(program, solver);
	if (initial.empty() || count_point_support(support, initial) < floor)
		return {};

	Constraint preserve_objective;
	for (const auto& term : primary.coefficients())
		preserve_objective.add_coefficient(term.first, term.second);
	constexpr double objective_tolerance = 1e-7;
	const double bound = objective_value(primary, initial) + objective_tolerance;
	upper_bound(program, preserve_objective, bound);
	program.set_objective(prefer_support, Program::MINIMIZE);
	auto preferred = solve(program, solver);
	if (preferred.empty() || objective_value(primary, preferred) > bound ||
		count_point_support(support, preferred) < count_point_support(support, initial))
		return initial;
	return preferred;
}

bool clears_quality_gate(const RoofSelection& candidate, const RoofSelection& reference)
{
	if (!candidate.has_roof())
		return false;
	if (!reference.has_roof())
		return true;

	const auto& a = candidate.report;
	const auto& b = reference.report;
	constexpr double tolerance = 1e-12;
	if (!std::isfinite(a.roof_fit_p95) || !std::isfinite(b.roof_fit_p95))
		return false;
	return a.roof_coverage + tolerance >= b.roof_coverage &&
		a.roof_overlap <= b.roof_overlap + tolerance &&
		a.open_roof_edges <= b.open_roof_edges &&
		a.roof_fit_p95 <= b.roof_fit_p95 + tolerance &&
		a.roof_point_coverage + tolerance >= b.roof_point_coverage &&
		(b.roof_fit_p95 - a.roof_fit_p95 >= 0.02 - tolerance ||
		 a.roof_point_coverage - b.roof_point_coverage >= 0.01 - tolerance);
}

bool better_quality(const RoofSelection& a, const RoofSelection& b)
{
	if (a.report.roof_fit_p95 != b.report.roof_fit_p95)
		return a.report.roof_fit_p95 < b.report.roof_fit_p95;
	return a.report.roof_point_coverage > b.report.roof_point_coverage;
}

void require_point_count(Program& program, const FaceSelectionPointSupport::Result& support,
	std::size_t required)
{
	if (required == 0)
		return;
	Constraint count;
	for (const auto& group : support.groups)
	{
		const auto index = group.facets.size() == 1 ? group.facets.front()
			: support_indicator(program, group.facets);
		count.add_coefficient(index, static_cast<double>(group.point_count));
	}
	lower_bound(program, count, static_cast<double>(required));
}

void preserve_roof_geometry(Program& program, const RoofSelection& baseline,
	const std::vector<FaceSelectionScores::Facet>& facets,
	const std::vector<FaceSelectionScores::Edge>& edges, const std::vector<vec2>& samples)
{
	std::vector<std::size_t> ids;
	std::vector<RoofGeometry> roofs;
	for (std::size_t i = 0; i < facets.size(); ++i)
		if (facets[i].roof && facets[i].face && facets[i].plane)
		{
			ids.push_back(i);
			roofs.emplace_back(facets[i]);
		}

	// Keep every footprint sample that was covered by the baseline.
	std::set<std::vector<std::size_t>> covered_patterns;
	for (const auto& sample : samples)
	{
		std::vector<std::size_t> pattern;
		bool covered = false;
		for (std::size_t i = 0; i < roofs.size(); ++i)
			if (contains_projection(roofs[i], sample))
			{
				pattern.push_back(ids[i]);
				covered = covered || selected(baseline.values, ids[i]);
			}
		if (covered)
			covered_patterns.insert(std::move(pattern));
	}
	for (const auto& pattern : covered_patterns)
	{
		Constraint cover;
		for (const auto i : pattern)
			cover.add_coefficient(i, 1.0);
		lower_bound(program, cover, 1.0);
	}

	if (baseline.report.open_roof_edges != 0)
		return;
	for (const auto& edge : edges)
		if (edge.facets.size() >= 2)
			for (const auto i : edge.facets)
				if (facets[i].roof)
				{
					Constraint joined;
					for (const auto j : edge.facets)
						joined.add_coefficient(j, j == i ? 1.0 : -1.0);
					upper_bound(program, joined, 0.0);
				}
}

void exclude_labels(Program& program, const std::vector<double>& values, std::size_t facet_count)
{
	Constraint different;
	std::size_t chosen = 0;
	for (std::size_t i = 0; i < facet_count; ++i)
	{
		const bool used = selected(values, i);
		different.add_coefficient(i, used ? 1.0 : -1.0);
		chosen += used;
	}
	upper_bound(program, different, static_cast<double>(chosen) - 1.0);
}

template <typename Evaluate>
void search_roof_alternatives(const Program& base, const RoofSelection& baseline,
	const FaceSelectionPointSupport::Result& near_support,
	const std::vector<FaceSelectionScores::Facet>& facets,
	const std::vector<FaceSelectionScores::Edge>& edges,
	const std::vector<vec2>& samples, const std::vector<vec3>& points,
	LinearProgramSolver::SolverName solver, const Evaluate& evaluate,
	const FaceSelectionFeedback& feedback)
{
	constexpr double minimum_gain = 0.001;
	constexpr double tolerance = 1e-8;
	constexpr int max_rounds = 3;
	const auto& reference = baseline.report;
	const auto roof_count = std::count_if(facets.begin(), facets.end(), [](const auto& f) { return f.roof; });
	if (!baseline.has_roof() || points.empty() || !std::isfinite(reference.roof_fit_p95) ||
		reference.roof_fit_p95 <= minimum_gain ||
		static_cast<std::size_t>(roof_count) <= reference.selected_roofs.size())
		return;

	// ceil(0.95 * N), the count matching the reported P95 rank.
	const std::size_t needed = points.size() - points.size() / 20;
	const std::size_t near_floor = count_point_support(near_support, baseline.values);
	double incumbent = reference.roof_fit_p95;
	Program protected_model = base;
	for (int round = 0; round < max_rounds && incumbent > minimum_gain; ++round)
	{
		const double target = incumbent - minimum_gain;
		const auto support = FaceSelectionPointSupport::compute(points, facets, target);
		std::size_t possible = 0;
		for (const auto& group : support.groups)
			possible += group.point_count;
		if (possible < needed)
			break;

		if (round == 0)
		{
			preserve_roof_geometry(protected_model, baseline, facets, edges, samples);
			require_point_count(protected_model, near_support, near_floor);
		}
		Program trial = protected_model;
		require_point_count(trial, support, needed);
		auto candidate = evaluate(solve(trial, solver), "p95_feedback", true);
		if (!candidate.has_roof())
			break;

		auto& report = candidate.report;
		if (count_point_support(support, candidate.values) < needed ||
			count_point_support(near_support, candidate.values) < near_floor ||
			report.roof_coverage + tolerance < reference.roof_coverage ||
			report.roof_overlap > reference.roof_overlap + tolerance ||
			report.open_roof_edges > reference.open_roof_edges ||
			!std::isfinite(report.roof_fit_p95) || report.roof_fit_p95 > target + tolerance)
		{
			exclude_labels(protected_model, candidate.values, facets.size());
			continue;
		}
		report.support_floor = static_cast<double>(near_floor) / points.size();
		feedback(report);
		incumbent = report.roof_fit_p95;
	}
}

} // namespace

bool FaceSelection::optimize(PolyFitInfo* polyfit_info, Map::Facet* footprint,
	std::vector<Plane3d*>& vertical_planes, LinearProgramSolver::SolverName solver_name,
	FaceSelectionMode mode, const FaceSelectionFeedback& feedback)
{
	std::vector<FaceSelectionReport> reports;
	return optimize_modes(polyfit_info, footprint, vertical_planes, solver_name,
		{mode}, mode, reports, false, feedback);
}

bool FaceSelection::optimize_comparison(PolyFitInfo* polyfit_info, Map::Facet* footprint,
	std::vector<Plane3d*>& vertical_planes, LinearProgramSolver::SolverName solver_name,
	const std::vector<FaceSelectionMode>& modes, FaceSelectionMode output_mode,
	std::vector<FaceSelectionReport>& reports, const FaceSelectionFeedback& feedback)
{
	return optimize_modes(polyfit_info, footprint, vertical_planes, solver_name,
		modes, output_mode, reports, true, feedback);
}

bool FaceSelection::optimize_modes(PolyFitInfo* polyfit_info, Map::Facet* footprint,
	std::vector<Plane3d*>& vertical_planes, LinearProgramSolver::SolverName solver_name,
	const std::vector<FaceSelectionMode>& modes, FaceSelectionMode output_mode,
	std::vector<FaceSelectionReport>& reports, bool measure, const FaceSelectionFeedback& feedback)
{
	reports.assign(modes.size(), FaceSelectionReport());
	if (!pset_ || !model_ || model_->size_of_facets() == 0 ||
		std::find(modes.begin(), modes.end(), output_mode) == modes.end())
		return false;

	facet_attrib_supporting_vertex_group_.bind_if_defined(model_, Method::facet_attrib_supporting_vertex_group);
	facet_attrib_supporting_point_num_.bind_if_defined(model_, Method::facet_attrib_supporting_point_num);
	facet_attrib_facet_area_.bind_if_defined(model_, Method::facet_attrib_facet_area);
	facet_attrib_supporting_plane_.bind_if_defined(model_, "FacetSupportingPlane");
	if (!facet_attrib_supporting_vertex_group_.is_bound() || !facet_attrib_supporting_point_num_.is_bound() ||
		!facet_attrib_facet_area_.is_bound() || !facet_attrib_supporting_plane_.is_bound())
	{
		Logger::err("-") << "Missing candidate face attributes" << std::endl;
		return false;
	}

	MapFacetAttribute<std::size_t> facet_indices(model_);
	std::vector<FaceSelectionScores::Facet> facets;
	FOR_EACH_FACET(Map, model_, it)
	{
		Map::Facet* face = it;
		auto plane = facet_attrib_supporting_plane_[face];
		const bool roof = std::find(vertical_planes.begin(), vertical_planes.end(), plane) == vertical_planes.end();
		facet_indices[face] = facets.size();
		facets.push_back({face, facet_attrib_supporting_vertex_group_[face], plane, roof});
	}

	const std::vector<FaceStar> fans = adjacency_.extract(model_, polyfit_info->planes);
	MapFacetAttribute<bool> is_confident_facet(model_, "is_confident_facet");
	std::vector<FaceSelectionScores::Edge> edges;
	edges.reserve(fans.size());
	std::vector<std::size_t> boundary_edges(facets.size(), 0);
	for (const auto& fan : fans)
	{
		Map::Halfedge* halfedge = fan.front();
		FaceSelectionScores::Edge edge{halfedge->vertex()->point(), halfedge->opposite()->vertex()->point(), {}};
		for (Map::Halfedge* member : fan)
			edge.facets.push_back(facet_indices[member->facet()]);
		std::sort(edge.facets.begin(), edge.facets.end());
		edge.facets.erase(std::unique(edge.facets.begin(), edge.facets.end()), edge.facets.end());
		if (fan.size() == 1)
			++boundary_edges[edge.facets.front()];
		edges.push_back(std::move(edge));
	}

	const std::size_t no_variable = std::numeric_limits<std::size_t>::max();
	std::vector<std::size_t> edge_used(fans.size(), no_variable);
	std::vector<std::size_t> edge_sharp(fans.size(), no_variable);
	Program base;
	for (std::size_t i = 0; i < facets.size(); ++i)
		binary_variable(base);
	for (std::size_t i = 0; i < fans.size(); ++i)
		if (fans[i].size() > 2)
			edge_used[i] = binary_variable(base);
	for (std::size_t i = 0; i < fans.size(); ++i)
		if (fans[i].size() == 4)
			edge_sharp[i] = binary_variable(base);

	// Keep the shared-edge topology constraints identical across the comparison.
	for (std::size_t i = 0; i < fans.size(); ++i)
	{
		if (edge_used[i] != no_variable)
		{
			Constraint incidence;
			for (Map::Halfedge* member : fans[i])
				incidence.add_coefficient(facet_indices[member->facet()], 1.0);
			incidence.add_coefficient(edge_used[i], -2.0);
			incidence.set_bounds(Constraint::FIXED, 0.0, 0.0);
			base.add_constraint(incidence);
		}
		if (edge_sharp[i] == no_variable)
			continue;

		Constraint sharp_implies_used;
		sharp_implies_used.add_coefficient(edge_sharp[i], 1.0);
		sharp_implies_used.add_coefficient(edge_used[i], -1.0);
		upper_bound(base, sharp_implies_used, 0.0);
		const auto& edge = edges[i];
		for (std::size_t j = 0; j < edge.facets.size(); ++j)
			for (std::size_t k = j + 1; k < edge.facets.size(); ++k)
			{
				const std::size_t first = edge.facets[j], second = edge.facets[k];
				if (facets[first].plane == facets[second].plane)
					continue;
				Constraint sharp;
				sharp.add_coefficient(first, 1.0);
				sharp.add_coefficient(second, 1.0);
				sharp.add_coefficient(edge_used[i], 1.0);
				sharp.add_coefficient(edge_sharp[i], -1.0);
				upper_bound(base, sharp, 2.0);
			}
	}
	for (std::size_t i = 0; i < facets.size(); ++i)
	{
		if (facets[i].roof && is_confident_facet[facets[i].face])
			fix(base, i, 1.0);
		else if (!facets[i].roof && boundary_edges[i] > 2)
			fix(base, i, 0.0);
	}

	std::set<std::vector<std::size_t>> overlap_groups;
	for (const auto& group : find_multi_roofs(model_, footprint, vertical_planes))
	{
		std::set<std::size_t> ids;
		for (auto face : group)
			ids.insert(facet_indices[face]);
		overlap_groups.emplace(ids.begin(), ids.end());
	}
	for (const auto& group : overlap_groups)
	{
		Constraint single_roof;
		for (const std::size_t index : group)
			single_roof.add_coefficient(index, 1.0);
		single_roof.set_bounds(Constraint::FIXED, 1.0, 1.0);
		base.add_constraint(single_roof);
	}

	const double total_points = static_cast<double>(pset_->points().size());
	const double z_max = model_->bbox().z_max();
	const double z_height = z_max - model_->bbox().z_min();
	const double box_area = model_->bbox().area();
	const double height_scale = z_height > 0.0
		? total_points * Method::lambda_model_height / z_height / facets.size() : 0.0;
	const double complexity_scale = fans.empty()
		? 0.0 : total_points * Method::lambda_model_complexity / fans.size();
	const double vertical_scale = box_area > 0.0
		? 0.1 * total_points * Method::lambda_model_complexity / box_area : 0.0;
	Objective legacy_geometry;
	for (std::size_t i = 0; i < facets.size(); ++i)
	{
		const auto& facet = facets[i];
		const Polygon3d polygon = Geom::facet_polygon(facet.face);
		double z_sum = 0.0;
		for (const vec3& vertex : polygon)
			z_sum += vertex.z;
		legacy_geometry.add_coefficient(i, height_scale * (z_max - z_sum / polygon.size()));
		if (!facet.roof)
			legacy_geometry.add_coefficient(i, vertical_scale * facet_attrib_facet_area_[facet.face]);
	}
	for (const std::size_t sharp : edge_sharp)
		if (sharp != no_variable)
			legacy_geometry.add_coefficient(sharp, complexity_scale);


	using Mode = FaceSelectionMode;
	const auto requested = [&modes](Mode mode) {
		return std::find(modes.begin(), modes.end(), mode) != modes.end();
	};
	const bool guard = requested(Mode::Guarded);
	const bool protect = guard || requested(Mode::Protected);
	const bool topology = protect || requested(Mode::Topology);
	const bool full = topology || requested(Mode::Equation23);
	const bool data_only = requested(Mode::Data);
	const bool new_data = full || data_only;
	const bool measure_roofs = measure || guard;

	const FaceSelectionScores::Result scores = new_data
		? FaceSelectionScores::compute(pset_, footprint, facets, edges, full) : FaceSelectionScores::Result();
	const auto conflicts = topology ? FaceSelectionScores::overlapping_roofs(footprint, facets) : RoofConflicts();

	std::vector<vec2> samples;
	std::vector<vec3> points;
	if (measure_roofs || protect)
	{
		const Polygon2d polygon = footprint_polygon(footprint);
		if (measure_roofs)
			samples = footprint_samples(polygon);
		points = FaceSelectionPointSupport::evaluation_points(*pset_, polygon);
	}

	auto evaluate = [&](std::vector<double> solution, const char* name, bool use_conflicts) {
		RoofSelection result;
		result.values = std::move(solution);
		auto& report = result.report;
		report.candidate_count = facets.size();
		report.overlap_conflicts = use_conflicts ? conflicts.size() : 0;
		report.selection_source = name;
		if (result.values.empty() || (use_conflicts && !meets_overlap_constraints(result.values, conflicts)))
			return result;
		report.solved = true;
		report.data = new_data ? 1.0 : 0.0;
		for (std::size_t i = 0; i < facets.size(); ++i)
		{
			if (!selected(result.values, i))
				continue;
			report.selected_facets.push_back(i);
			if (facets[i].roof)
				report.selected_roofs.push_back(i);
			if (new_data)
			{
				report.data -= scores.support[i];
				report.area += scores.area_penalty[i];
			}
		}
		std::map<std::size_t, double> edge_credit;
		for (const auto& ridge : scores.ridges)
			if (selected(result.values, ridge.first) && selected(result.values, ridge.second))
				edge_credit[ridge.edge] = std::max(edge_credit[ridge.edge], ridge.reward);
		for (const auto& edge : edge_credit)
			report.curvature -= edge.second;
		for (const auto& boundary : scores.boundary)
			if (std::any_of(boundary.facets.begin(), boundary.facets.end(),
				[&result](std::size_t index) { return selected(result.values, index); }))
				report.boundary -= boundary.reward;

		if (measure_roofs)
			measure_roof(report, result.values, facets, edges, samples, points);
		return result;
	};

	Objective legacy_objective = legacy_geometry;
	Objective data_objective = legacy_geometry;
	Objective equation23_objective;
	for (std::size_t i = 0; i < facets.size(); ++i)
	{
		const double count = facet_attrib_supporting_point_num_[facets[i].face];
		legacy_objective.add_coefficient(i, -Method::lambda_data_fitting * count);
		if (data_only)
		{
			const double support = facets[i].roof ? total_points * scores.support[i] : count;
			data_objective.add_coefficient(i, -Method::lambda_data_fitting * support);
		}
		if (full)
			equation23_objective.add_coefficient(i, -data_weight * scores.support[i] + area_weight * scores.area_penalty[i]);
	}

	std::map<Mode, RoofSelection> comparisons;
	if (protect || requested(Mode::Legacy))
	{
		base.set_objective(legacy_objective, Program::MINIMIZE);
		comparisons[Mode::Legacy] = evaluate(solve(base, solver_name), "legacy", false);
	}
	if (data_only)
	{
		base.set_objective(data_objective, Program::MINIMIZE);
		comparisons[Mode::Data] = evaluate(solve(base, solver_name), "data", false);
	}

	RoofSelection repaired_legacy;
	const RoofSelection* reference = nullptr;
	FaceSelectionPointSupport::Result support{};
	if (full)
	{
		add_structure_scores(base, equation23_objective, scores);
		// E_data's constant does not affect the minimizer.
		base.set_objective(equation23_objective, Program::MINIMIZE);
		if (guard || requested(Mode::Equation23))
			comparisons[Mode::Equation23] = evaluate(solve(base, solver_name), "equation23", false);
	}
	if (topology)
	{
		require_single_layer(base, conflicts);
		if (requested(Mode::Topology))
			comparisons[Mode::Topology] = evaluate(solve(base, solver_name), "topology", true);
	}
	if (protect)
	{
		const auto& legacy = comparisons.at(Mode::Legacy);
		support = FaceSelectionPointSupport::compute(points, facets);
		if (legacy.has_roof() && meets_overlap_constraints(legacy.values, conflicts))
		{
			reference = &legacy;
		}
		else if (legacy.has_roof())
		{
			// Use a feasible reference rather than scoring the original overlapping layers.
			base.set_objective(legacy_objective, Program::MINIMIZE);
			repaired_legacy = evaluate(solve(base, solver_name), "repaired_legacy", true);
			base.set_objective(equation23_objective, Program::MINIMIZE);
			if (repaired_legacy.has_roof())
				reference = &repaired_legacy;
		}

		const std::size_t floor = reference ? count_point_support(support, reference->values) : 0;
		auto protected_result = evaluate(solve_with_support_floor(base, support, floor, solver_name),
			"protected", true);
		protected_result.report.support_floor = support.point_count == 0
			? 0.0 : static_cast<double>(floor) / support.point_count;
		comparisons[Mode::Protected] = std::move(protected_result);
	}
	if (guard)
	{
		const auto& legacy = comparisons.at(Mode::Legacy);
		const RoofSelection empty;
		const auto& baseline = reference ? *reference : empty;
		const RoofSelection* best = &baseline;
		for (const Mode mode : {Mode::Protected, Mode::Equation23})
		{
			const auto& candidate = comparisons.at(mode);
			if (candidate.has_roof() && meets_overlap_constraints(candidate.values, conflicts)
				&& clears_quality_gate(candidate, baseline) && (best == &baseline || better_quality(candidate, *best)))
				best = &candidate;
		}
		auto result = *best;
		result.report.candidate_count = facets.size();
		result.report.overlap_conflicts = conflicts.size();
		result.report.support_floor = comparisons.at(Mode::Protected).report.support_floor;
		if (!best->has_roof() && legacy.has_roof())
			result.report.selection_source = "unresolved_overlap";
		comparisons[Mode::Guarded] = std::move(result);
		if (output_mode == Mode::Guarded && feedback)
			search_roof_alternatives(base, comparisons.at(Mode::Guarded), support, facets, edges,
				samples, points, solver_name, evaluate, feedback);
	}

	for (std::size_t i = 0; i < modes.size(); ++i)
		reports[i] = comparisons.at(modes[i]).report;
	const auto& result = comparisons.at(output_mode);
	const auto& output = result.values;
	if (!result.has_roof())
	{
		Logger::warn("-") << "Face selection produced no roof for the requested output mode." << std::endl;
		return false;
	}

	MapHalfedgeAttribute<bool> edge_is_sharp(model_, "SharpEdge");
	FOR_EACH_HALFEDGE(Map, model_, it)
		edge_is_sharp[it] = false;
	for (std::size_t i = 0; i < fans.size(); ++i)
	{
		if (edge_sharp[i] == no_variable || !selected(output, edge_sharp[i]))
			continue;
		for (Map::Halfedge* halfedge : fans[i])
			if (selected(output, facet_indices[halfedge->facet()]))
			{
				edge_is_sharp[halfedge] = true;
				break;
			}
	}
	MapEditor editor(model_);
	for (std::size_t i = 0; i < facets.size(); ++i)
		if (!selected(output, i))
			editor.erase_facet(facets[i].face->halfedge());

	MapFacetNormal normal(model_);
	FOR_EACH_FACET(Map, model_, it)
		normal[it] = facet_attrib_supporting_plane_[it]->normal();
	return true;
}
