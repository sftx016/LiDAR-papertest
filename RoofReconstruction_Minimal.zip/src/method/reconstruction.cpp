#include "reconstruction.h"
#include "hypothesis_generator.h"
#include "face_selection_point_support.h"
#include "roof_fit_refinement.h"
#include "watertight_mesh.h"
#include "point_set_normals.h"
#include "cgal_types.h"
#include "point_set_region_growing.h"
#include "../basic/logger.h"
#include "../basic/progress.h"
#include "../basic/stop_watch.h"
#include "../model/kdtree_search.h"
#include "../model/map_geometry.h"
#include "../model/map_io.h"
#include "method_global.h"
#include "../model/map_circulators.h"
#include "../model/map_builder.h"
#include "../model/map_copier.h"
#include "../model/map_editor.h"
#include "../method/dbscan.h"
#include "alpha_shape_boundary.h"
#include "otr2_edge_simplify.h"
#include "alpha_shape_mesh.h"
#include "../model/point_set_io.h"
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/intersections.h>
#include <CGAL/bounding_box.h>
#include <CGAL/Projection_traits_xy_3.h>
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <locale>
#include <sstream>
#include <vector>
#include <cmath>
#include <utility>
#include <CGAL/Delaunay_triangulation_2.h>
#include <CGAL/interpolation_functions.h>


typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef K::FT FT;
typedef K::Point_3 Point_3d;
typedef CGAL::Projection_traits_xy_3<K> Gt;
typedef CGAL::Delaunay_triangulation_2<Gt> Delaunay_triangulation;
typedef Delaunay_triangulation::Face_handle Face_handle;

double image_x_min;
double image_y_min;
double image_delta_res;

void Reconstruction::segmentation(PointSet *pset, Map *foot_print)
{
	if (!pset)
	{
		Logger::warn("-") << "point cloud data does not exist" << std::endl;
		return;
	}
	if (!foot_print)
	{
		Logger::warn("-") << "foot print data does not exist" << std::endl;
	}
	pset->groups().clear();

	//	Logger::out("-") << "building kd-tree..." << std::endl;
	StopWatch w;
	// estimate the best z value
	double avg_z = 0.0;
	FOR_EACH_VERTEX_CONST(Map, foot_print, it) avg_z += it->point().z;
	avg_z /= foot_print->size_of_vertices();

	KdTreeSearch_var kdtree = new KdTreeSearch;
	kdtree->begin();
	// I need a 2D version of the point cloud
	std::vector<vec3> backup_points = pset->points();

	std::vector<vec3> points = pset->points();
	for (std::size_t i = 0; i < points.size(); ++i)
	{
		points[i].z = avg_z;
		kdtree->add_point(&points[i]);
	}
	kdtree->end();
	w.start();

	MapFacetAttribute<VertexGroup::Ptr> buildings(foot_print, "buildings");

	std::vector<VertexGroup::Ptr> &groups = pset->groups();
	ProgressLogger progress(foot_print->size_of_facets());
	FOR_EACH_FACET_CONST(Map, foot_print, it)
	{
		const Polygon3d &plg = it->to_polygon();
		Polygon2d plg2d;
		Box3d box;
		for (std::size_t i = 0; i < plg.size(); ++i)
		{
			const vec3 &p = plg[i];
			plg2d.push_back(vec2(p.x, p.y));
			box.add_point(vec3(p.x, p.y, avg_z));
		}

		std::vector<unsigned int> nbs;
		double r = box.radius();
		kdtree->find_points_in_radius(box.center(), r * r, nbs);

		std::vector<unsigned char> inside(nbs.size(), 0);
#pragma omp parallel for
		for (int i = 0; i < nbs.size(); ++i)
		{
			unsigned int idx = nbs[i];
			vec2 p(points[idx].x, points[idx].y);
			if (Geom::point_is_in_polygon(plg2d, p))
			{
				inside[i] = 1;
			}
		}

		VertexGroup::Ptr g = new VertexGroup;
		for (int i = 0; i < nbs.size(); ++i)
		{
			if (inside[i])
			{
				g->push_back(nbs[i]);
			}
		}
		if (!g->empty())
		{
			g->set_color(random_color());
			groups.push_back(g);
			buildings[it] = g;
		}

		progress.next();
	}

}

// RANSAC implementation retained for reference; disabled to avoid a duplicate definition.
void Reconstruction::extract_building_roof(
	PointSet* pset,
	VertexGroup* building,
	unsigned int min_support
)
{
	std::vector<VertexGroup::Ptr> roofs;

	if (pset == nullptr || building == nullptr)
	{
		return;
	}

	std::vector<unsigned int> p_index = *building;

	if (p_index.size() < min_support)
	{
		building->set_children(roofs);
		return;
	}

	if (!pset->has_normals())
	{
		Logger::out() << "RANSAC roof detection requires point cloud normals" << std::endl;
		building->set_children(roofs);
		return;
	}

	const std::vector<vec3>& points = pset->points();
	const std::vector<vec3>& normals = pset->normals();

	if (points.empty() || normals.size() != points.size())
	{
		building->set_children(roofs);
		return;
	}

	// ------------------------------------------------------------
	// 参数设置
	// ------------------------------------------------------------
	const double dist_thresh = 0.1;        // 点到平面距离阈值
	const double bitmap_reso = 0.5;        // RANSAC bitmap epsilon

	// 20 度法向夹角阈值，degree -> radian
	const double normal_thresh = std::cos(20.0 * 3.1415926 / 180.0);


	// 只过滤低位平区域：
	// abs(c) 越接近 1，说明平面越接近水平
	const double low_flat_normal_z_thresh = 0.85;

	// ------------------------------------------------------------
	// 1. 构建 RANSAC 输入点云
	// ------------------------------------------------------------
	RANSAC_PointCloud m_cloud;

	double min_z = 1e30;
	double max_z = -1e30;

	Vec3f cbbMin;
	Vec3f cbbMax;

	cbbMin[0] = 1e30f;
	cbbMin[1] = 1e30f;
	cbbMin[2] = 1e30f;

	cbbMax[0] = -1e30f;
	cbbMax[1] = -1e30f;
	cbbMax[2] = -1e30f;

	for (std::size_t i = 0; i < p_index.size(); ++i)
	{
		unsigned int idx = p_index[i];

		if (idx >= points.size())
			continue;

		const vec3& p = points[idx];
		const vec3& n = normals[idx];

		double nx = static_cast<double>(n.x);
		double ny = static_cast<double>(n.y);
		double nz = static_cast<double>(n.z);

		double nlen = std::sqrt(nx * nx + ny * ny + nz * nz);

		if (nlen < 1e-12)
			continue;

		nx /= nlen;
		ny /= nlen;
		nz /= nlen;

		RANSAC_Point Pt;

		Pt.pos[0] = static_cast<float>(p.x);
		Pt.pos[1] = static_cast<float>(p.y);
		Pt.pos[2] = static_cast<float>(p.z);

		// 直接使用原始点云 normal，不重新计算
		Pt.normal[0] = static_cast<float>(nx);
		Pt.normal[1] = static_cast<float>(ny);
		Pt.normal[2] = static_cast<float>(nz);

		m_cloud.push_back(Pt);

		if (Pt.pos[0] < cbbMin[0]) cbbMin[0] = Pt.pos[0];
		if (Pt.pos[1] < cbbMin[1]) cbbMin[1] = Pt.pos[1];
		if (Pt.pos[2] < cbbMin[2]) cbbMin[2] = Pt.pos[2];

		if (Pt.pos[0] > cbbMax[0]) cbbMax[0] = Pt.pos[0];
		if (Pt.pos[1] > cbbMax[1]) cbbMax[1] = Pt.pos[1];
		if (Pt.pos[2] > cbbMax[2]) cbbMax[2] = Pt.pos[2];

		if (p.z < min_z) min_z = p.z;
		if (p.z > max_z) max_z = p.z;
	}

	if (m_cloud.size() < min_support)
	{
		building->set_children(roofs);
		return;
	}

	if (max_z <= min_z)
	{
		building->set_children(roofs);
		return;
	}

	m_cloud.setBBox(cbbMin, cbbMax);

	const double height_filter = min_z + 0.25 * (max_z - min_z);

	// ------------------------------------------------------------
	// 2. RANSAC 检测平面
	// ------------------------------------------------------------
	RansacShapeDetector::Options ransacOptions;
	ransacOptions.m_epsilon = static_cast<float>(dist_thresh);
	ransacOptions.m_bitmapEpsilon = static_cast<float>(bitmap_reso);
	ransacOptions.m_normalThresh = static_cast<float>(normal_thresh);
	ransacOptions.m_probability = 0.001f;
	ransacOptions.m_minSupport = 30;

	RansacShapeDetector detector(ransacOptions);
	detector.Add(new PlanePrimitiveShapeConstructor());

	MiscLib::Vector<std::pair<MiscLib::RefCountPtr<PrimitiveShape>, size_t>> shapes;

	detector.Detect(
		m_cloud,
		0,
		m_cloud.size(),
		&shapes
	);
	bool has_valid_shape = false;

	for (auto it = shapes.begin(); it != shapes.end(); ++it)
	{
		if (it->first != nullptr && it->second >= min_support)
		{
			has_valid_shape = true;
			break;
		}
	}

	if (!has_valid_shape)
	{
		Logger::warn("-") << "RANSAC returned no valid shape. "
			<< "total shapes = " << shapes.size()
			<< ", min support = " << min_support << std::endl;

		building->set_children(roofs);
		return;
	}

	if (has_valid_shape)
	{
		// ------------------------------------------------------------
		// 3. 根据 RANSAC 平面，在原始 p_index 中重新筛选内点
		//    注意：不依赖 RANSAC 内部点顺序，保证输出索引仍是 pset 全局索引
		// ------------------------------------------------------------

		int plane_id = 0;

		for (MiscLib::Vector<std::pair<MiscLib::RefCountPtr<PrimitiveShape>, size_t>>::const_iterator it = shapes.begin();
			it != shapes.end(); ++it)
		{
			const PrimitiveShape* shape = it->first;

			if (shape == nullptr)
				continue;

			if (it->second < min_support)
				continue;

			// 这里只处理平面
			if (shape->Identifier() != 0)
				continue;

			const PlanePrimitiveShape* plane_shape =
				static_cast<const PlanePrimitiveShape*>(shape);

			Vec3f normal0 = plane_shape->Internal().getNormal();
			Vec3f center0 = plane_shape->Internal().getPosition();

			double a = static_cast<double>(normal0[0]);
			double b = static_cast<double>(normal0[1]);
			double c = static_cast<double>(normal0[2]);

			double len = std::sqrt(a * a + b * b + c * c);

			if (len < 1e-12)
				continue;

			a /= len;
			b /= len;
			c /= len;

			// 统一法向朝上，仅用于平面参数稳定；
			// 不根据坡度删除倾斜屋顶或近垂直结构。
			if (c < 0.0)
			{
				a = -a;
				b = -b;
				c = -c;
			}

			double cx = static_cast<double>(center0[0]);
			double cy = static_cast<double>(center0[1]);
			double cz = static_cast<double>(center0[2]);

			double d = -(a * cx + b * cy + c * cz);

			// --------------------------------------------------------
			// 4. 先用临时数组收集候选点
			//    注意：这里不 new VertexGroup，不 push 到 roof
			// --------------------------------------------------------
			std::vector<unsigned int> roof_indices;
			roof_indices.reserve(static_cast<std::size_t>(it->second));

			double sum_z = 0.0;
			std::size_t valid_num = 0;

			for (std::size_t i = 0; i < p_index.size(); ++i)
			{
				unsigned int idx = p_index[i];

				if (idx >= points.size())
					continue;

				const vec3& p = points[idx];
				const vec3& n = normals[idx];

				double px = static_cast<double>(p.x);
				double py = static_cast<double>(p.y);
				double pz = static_cast<double>(p.z);

				double dist = std::abs(a * px + b * py + c * pz + d);

				if (dist > dist_thresh)
					continue;

				double nx = static_cast<double>(n.x);
				double ny = static_cast<double>(n.y);
				double nz = static_cast<double>(n.z);

				double nlen = std::sqrt(nx * nx + ny * ny + nz * nz);

				if (nlen > 1e-12)
				{
					nx /= nlen;
					ny /= nlen;
					nz /= nlen;

					double dot = std::abs(a * nx + b * ny + c * nz);

					if (dot < normal_thresh)
						continue;
				}

				roof_indices.push_back(idx);
				sum_z += pz;
				++valid_num;
			}

			if (roof_indices.size() < min_support || valid_num == 0)
			{
				continue;
			}

			double avg_z = sum_z / static_cast<double>(valid_num);

			// --------------------------------------------------------
			// 5. 只过滤低位平区域
			// --------------------------------------------------------
			// 低位 + 接近水平 -> 删除
			// 低位 + 倾斜面   -> 保留
			// 低位 + 近垂直面 -> 保留
			// 高位 + 任意坡度 -> 保留
			bool is_low_region = avg_z < height_filter;
			bool is_flat_region = std::abs(c) > low_flat_normal_z_thresh;

			if (is_low_region && is_flat_region)
			{
				continue;
			}

			// --------------------------------------------------------
			// 6. 所有检测通过后，再创建 roof，并加入点索引
			// --------------------------------------------------------
			VertexGroup::Ptr roof = new VertexGroup;

			for (std::size_t k = 0; k < roof_indices.size(); ++k)
			{
				roof->push_back(roof_indices[k]);
			}

			roof->set_plane(Plane3d(a, b, c, d));
			roof->set_point_set(pset);

			std::ostringstream label;
			label << "roof_ransac_" << plane_id;

			roof->set_color(random_color());

			roofs.push_back(roof);
			++plane_id;
		}
	}

	building->set_children(roofs);
}

#if 0
void Reconstruction::extract_building_roof(
	PointSet *pset,
	VertexGroup *building,
	unsigned int min_support
)
{
	if (pset == nullptr || building == nullptr)
		return;

	std::vector<unsigned int> p_index = *building;
	RegionGrowingDectetor rg;
	std::vector<VertexGroup::Ptr> roofs = rg.detect(pset, p_index, min_support);

	int tts = 0;
	for (auto& r : roofs)
	{
		tts++;
		if (tts == 268)
		{
			int tt2 = 1;
		}
		r->set_color(random_color());
	}

	building->set_children(roofs);
}
#endif
void Reconstruction::extract_roofs(PointSet *pset, Map *foot_print)
{
	if (!pset)
	{
		Logger::warn("-") << "point cloud data does not exist" << std::endl;
		return;
	}

	if (!foot_print)
	{
		Logger::warn("-") << "foot print data does not exist" << std::endl;
		return;
	}

	if (!MapFacetAttribute<VertexGroup::Ptr>::is_defined(foot_print, "buildings"))
	{
		Logger::warn("-") << "please segment the point cloud into buildings" << std::endl;
		return;
	}
	MapFacetAttribute<VertexGroup::Ptr> buildings(foot_print, "buildings");


	if (!pset->has_normals())
	{
		PointSetNormals::estimate(pset);
	}

	StopWatch t;
	t.start();

	ProgressLogger progress(foot_print->size_of_facets());
	FOR_EACH_FACET_CONST(Map, foot_print, it)
	{
		VertexGroup::Ptr g = buildings[it];
		if (!g)
			continue;
		extract_building_roof(pset, g, 30);
		progress.next();
	}

}

PointSet *Reconstruction::create_roof_point_set(const PointSet *pset,
	const std::vector<VertexGroup::Ptr> &segments, VertexGroup *building)
{
	const std::vector<vec3> &points = pset->points();
	const std::vector<vec3> &normals = pset->normals();
	const std::vector<vec3> &colors = pset->colors();
	PointSet *new_pset = new PointSet;
	std::vector<unsigned int> full_vector = *building;
	std::set<unsigned int> full_set(full_vector.begin(), full_vector.end());
	std::set<unsigned int> planar_set, remaining_set;
	int count = 0;

	for (std::size_t i = 0; i < segments.size(); ++i)
	{
		VertexGroup *vg = segments[i];

		VertexGroup::Ptr group = new VertexGroup;
		group->set_point_set(new_pset);
		group->set_plane(vg->plane());
		group->set_color(vg->color());
		for (int j = 0; j < vg->size(); ++j)
		{
			unsigned int idx = vg->at(j);
			new_pset->points().push_back(points[idx]);

			if (pset->has_normals())
				new_pset->normals().push_back(normals[idx]);
			if (pset->has_colors())
				new_pset->colors().push_back(colors[idx]);

			group->push_back(count);
			planar_set.insert(idx);
			++count;
		}
		new_pset->groups().push_back(group);
	}
	//add the remaining points.
	std::set_difference(full_set.begin(),
		full_set.end(),
		planar_set.begin(),
		planar_set.end(),
		inserter(remaining_set, remaining_set.begin()));

	for (auto iter = remaining_set.begin(); iter != remaining_set.end(); ++iter)
	{
		auto in_p = *iter;
		const vec3 &p = points[in_p];
		new_pset->points().push_back(p);
		if (pset->has_normals())
			new_pset->normals().push_back(normals[in_p]);
		if (pset->has_colors())
			new_pset->colors().push_back(colors[in_p]);
	}

	return new_pset;
}

PointSet *Reconstruction::create_projected_point_set(const PointSet *roof)
{
	if (roof == nullptr || roof->num_points() == 0)
		return new PointSet;

	KdTreeSearch_var kdtree = new KdTreeSearch;
	kdtree->begin();
	// I need a 2D version of the point cloud
	auto z_min = roof->bbox().z_min(), z_max = roof->bbox().z_max();
	auto y_min = roof->bbox().y_min(), y_max = roof->bbox().y_max();
	auto x_min = roof->bbox().x_min(), x_max = roof->bbox().x_max();
	double avg_z = (z_max + z_min) * 0.5;
	x_min -= 1;
	y_min -= 1;
	x_max += 1;
	y_max += 1;
	// Restrict height-image input to this building. Using the full scene
	// point cloud admits nearby buildings and creates false roof edges.
	std::vector<vec3> backup_points = roof->points();

	std::vector<vec3> points = roof->points();
	for (std::size_t i = 0; i < points.size(); ++i)
	{
		points[i].z = avg_z;
		kdtree->add_point(&points[i]);
	}
	kdtree->end();

	Polygon2d plg2d;
	Box3d box;
	std::vector<vec3> plg;
	plg.push_back(vec3(x_min, y_min, avg_z));
	plg.push_back(vec3(x_min, y_max, avg_z));
	plg.push_back(vec3(x_max, y_max, avg_z));
	plg.push_back(vec3(x_max, y_min, avg_z));

	for (std::size_t i = 0; i < plg.size(); ++i)
	{
		vec3 p = plg[i];
		plg2d.push_back(vec2(p.x, p.y));
		box.add_point(vec3(p.x, p.y, avg_z));
	}

	std::vector<unsigned int> nbs;
	double r = box.radius();
	kdtree->find_points_in_radius(box.center(), r * r, nbs);

	std::vector<unsigned char> inside(nbs.size(), 0);
#pragma omp parallel for
	for (int i = 0; i < nbs.size(); ++i)
	{
		unsigned int idx = nbs[i];
		vec2 p(points[idx].x, points[idx].y);
		if (Geom::point_is_in_polygon(plg2d, p))
		{
			inside[i] = 1;
		}
	}

	VertexGroup::Ptr g = new VertexGroup;
	for (int i = 0; i < nbs.size(); ++i)
	{
		if (inside[i])
		{
			g->push_back(nbs[i]);
		}
	}

	PointSet *new_pset = new PointSet;
	int count = 0;
	VertexGroup::Ptr group = new VertexGroup;
	group->set_point_set(new_pset);
	for (int j = 0; j < g->size(); ++j)
	{
		int idx = g->at(j);
		auto p = backup_points[idx];
		if (p.z < z_max)
		{
			new_pset->points().push_back(p);
			group->push_back(count);
			++count;
		}
	}
	new_pset->groups().push_back(group);

	return new_pset;
}

// create a point set from a set of planar segments

bool is_simple_polygon(const Map::Facet *f)
{
	const Plane3d &plane = Geom::facet_plane(f);
	Polygon_2 plg;
	FacetHalfedgeConstCirculator cir(f);
	for (; !cir->end(); ++cir)
	{
		const vec3 &p = cir->halfedge()->vertex()->point();
		const vec2 &q = plane.to_2d(p);
		plg.push_back(to_cgal_point(q));
	}
	return plg.is_simple();
}

namespace {

const std::vector<FaceSelectionMode>& comparison_modes()
{
	static const std::vector<FaceSelectionMode> modes = {
		FaceSelectionMode::Legacy, FaceSelectionMode::Data, FaceSelectionMode::Equation23,
		FaceSelectionMode::Topology, FaceSelectionMode::Protected, FaceSelectionMode::Guarded
	};
	return modes;
}

const char* comparison_mode_name(FaceSelectionMode mode)
{
	switch (mode)
	{
	case FaceSelectionMode::Legacy: return "legacy";
	case FaceSelectionMode::Data: return "data";
	case FaceSelectionMode::Equation23: return "equation23";
	case FaceSelectionMode::Topology: return "topology";
	case FaceSelectionMode::Protected: return "protected";
	case FaceSelectionMode::Guarded: return "guarded";
	}
	return "unknown";
}

vec3 facet_vertex_center(const Map::Facet* face)
{
	vec3 center(0, 0, 0);
	if (!face->halfedge())
		return center;
	std::size_t num_vertices = 0;
	FacetHalfedgeConstCirculator ring(face);
	for (; !ring->end(); ++ring)
	{
		center += ring->halfedge()->vertex()->point();
		++num_vertices;
	}
	return center / static_cast<double>(num_vertices);
}

class CandidateMapCopier : private MapMutator
{
public:
	Map::Ptr copy_selected(Map* source, const std::vector<std::size_t>& selected)
	{
		if (selected.empty() || selected.back() >= source->size_of_facets() ||
			!std::is_sorted(selected.begin(), selected.end()) ||
			std::adjacent_find(selected.begin(), selected.end()) != selected.end())
			return nil;

		Map::Ptr copy = new Map;
		MapBuilder builder(copy);
		builder.set_quiet(true);
		MapCopier copier;
		copier.set_copy_all_attributes(true);
		builder.begin_surface();
		copier.copy(builder, source);
		builder.end_surface();
		if (copy->size_of_vertices() != source->size_of_vertices() ||
			copy->size_of_facets() != source->size_of_facets() ||
			copy->size_of_halfedges() != source->size_of_halfedges())
			return nil;

		MapVertexAttribute<std::size_t> source_id(source), copy_id(copy);
		std::size_t id = 0;
		FOR_EACH_VERTEX(Map, source, it)
			source_id[it] = id++;
		id = 0;
		FOR_EACH_VERTEX(Map, copy, it)
			copy_id[it] = id++;

		MapHalfedgeAttribute<bool> source_boundary;
		source_boundary.bind_if_defined(source, "is_boundary");
		if (!source_boundary.is_bound())
			return nil;
		MapHalfedgeAttribute<bool> copy_boundary(copy, "is_boundary");
		MapFacetAttribute<Plane3d*> source_plane, copy_plane;
		source_plane.bind_if_defined(source, "FacetSupportingPlane");
		copy_plane.bind_if_defined(copy, "FacetSupportingPlane");
		if (!source_plane.is_bound() || !copy_plane.is_bound())
			return nil;

		std::vector<Map::Facet*> removed;
		auto original = source->facets_begin();
		auto keep = selected.begin();
		id = 0;
		FOR_EACH_FACET(Map, copy, it)
		{
			if (source_plane[*original] != copy_plane[it])
				return nil;
			auto* first = original->halfedge();
			auto* start = it->halfedge();
			while (source_id[first->vertex()] != copy_id[start->vertex()])
			{
				start = start->next();
				if (start == it->halfedge())
					return nil;
			}

			// The builder can rotate a facet ring and offset copied halfedge data.
			// Restore the original traversal and the flags used by wall extrusion.
			make_facet_key(start);
			auto* source_edge = first;
			auto* copy_edge = start;
			do
			{
				const bool is_border = source_edge->opposite()->facet() == nullptr;
				if (source_id[source_edge->vertex()] != copy_id[copy_edge->vertex()] ||
					length2(source_edge->vertex()->point() - copy_edge->vertex()->point()) != 0.0 ||
					is_border != (copy_edge->opposite()->facet() == nullptr))
					return nil;
				copy_boundary[copy_edge] = source_boundary[source_edge];
				if (is_border)
					copy_boundary[copy_edge->opposite()] = source_boundary[source_edge->opposite()];
				source_edge = source_edge->next();
				copy_edge = copy_edge->next();
				if ((source_edge == first) != (copy_edge == start))
					return nil;
			}
			while (source_edge != first);

			if (keep != selected.end() && *keep == id)
				++keep;
			else
				removed.push_back(it);
			++original;
			++id;
		}

		MapEditor editor(copy);
		for (auto* facet : removed)
			editor.erase_facet(facet->halfedge());
		return copy;
	}
};

void write_face_ids(std::ostream& csv, const std::vector<std::size_t>& ids)
{
	for (std::size_t i = 0; i < ids.size(); ++i)
	{
		if (i != 0)
			csv << ';';
		csv << ids[i];
	}
}

struct ShellReport {
	const char* status = "not_attempted";
	std::string detail;
	std::size_t vertices = 0;
	std::size_t faces = 0;
	RoofFitRefinement::Result fit;
};

void write_shell_report(std::ostream& csv, const ShellReport& shell)
{
	csv << ',' << shell.status << ",\"";
	for (const char c : shell.detail)
	{
		if (c == '"')
			csv << '"';
		csv << c;
	}
	csv << "\"," << shell.vertices << ',' << shell.faces << ',' << shell.fit.offset;
	if (std::isfinite(shell.fit.p95_before))
	{
		csv << ',' << shell.fit.p95_before << ',' << shell.fit.p95_after
			<< ',' << static_cast<double>(shell.fit.near_before) / shell.fit.point_count
			<< ',' << static_cast<double>(shell.fit.near_after) / shell.fit.point_count;
	}
	else
		csv << ",,,,";
}

RoofFitRefinement::Result refine_closed_roof(Map* shell, Map::Facet* footprint,
	const PointSet& roof_points, const std::vector<Map::Facet*>& stitched_faces,
	const std::vector<std::size_t>& roof_ids, std::string& detail, bool allow_offset)
{
	const auto outline = Geom::facet_polygon(footprint);
	const double ground_z = outline.front().z;
	constexpr double ground_tolerance = 1e-8;
	Polygon2d footprint_xy;
	for (const vec3& p : outline)
	{
		if (std::abs(p.z - ground_z) > ground_tolerance)
			return {};
		footprint_xy.push_back(vec2(p.x, p.y));
	}

	std::vector<Plane3d> roof_planes;
	std::vector<FaceSelectionScores::Facet> roofs;
	std::vector<std::size_t> ids;
	roof_planes.reserve(roof_ids.size());
	for (const std::size_t id : roof_ids)
	{
		auto* face = stitched_faces[id];
		if (!face)
			continue;
		const vec3 normal = Geom::facet_normal(face);
		if (length2(normal) <= 1e-16)
			return {};
		roof_planes.emplace_back(facet_vertex_center(face), normal);
		ids.push_back(roofs.size());
		roofs.push_back({face, nullptr, &roof_planes.back(), true});
	}

	const auto points = FaceSelectionPointSupport::evaluation_points(roof_points, footprint_xy);
	auto fit = RoofFitRefinement::vertical_offset(roofs, ids, points, ground_z, allow_offset);
	if (fit.offset == 0.0)
		return fit;

	const auto discard_offset = [&fit]() {
		fit.offset = 0.0;
		fit.p95_after = fit.p95_before;
		fit.near_after = fit.near_before;
	};
	std::vector<std::pair<Map::Vertex*, vec3>> lifted;
	FOR_EACH_VERTEX(Map, shell, it)
	{
		const vec3 p = it->point();
		if (std::abs(p.z - ground_z) <= ground_tolerance)
			continue;
		if (std::min(p.z, p.z + fit.offset) <= ground_z + ground_tolerance)
		{
			discard_offset();
			return fit;
		}
		lifted.emplace_back(it, p);
	}
	for (const auto& vertex : lifted)
		vertex.first->set_point(vertex.second + vec3(0.0, 0.0, fit.offset));

	std::string error;
	if (!WatertightMesh::validate(shell, error))
	{
		for (const auto& vertex : lifted)
			vertex.first->set_point(vertex.second);
		detail = "roof offset rejected: " + error;
		discard_offset();
	}
	shell->invalidate_bbox();
	shell->compute_facet_normals();
	return fit;
}


void write_selection_comparison(std::ostream* out, std::size_t building_id, const Map::Facet* footprint,
	const char* skipped_status, const std::vector<FaceSelectionReport>& reports = {},
	const std::vector<vec3>& candidate_centers = {}, FaceSelectionMode output_mode = FaceSelectionMode::Guarded,
	const ShellReport& shell = ShellReport())
{
	if (!out)
		return;

	const vec3 center = facet_vertex_center(footprint);
	std::ostringstream csv;
	csv.imbue(std::locale::classic());
	csv << std::setprecision(17);
	const auto& modes = comparison_modes();
	for (std::size_t i = 0; i < modes.size(); ++i)
	{
		const FaceSelectionReport* report = i < reports.size() ? &reports[i] : nullptr;
		const char* status = skipped_status;
		if (report)
		{
			status = !report->solved ? "solve_failed" :
				(report->selected_roofs.empty() ? "no_selected_roof" : "solved");
		}
		csv << building_id << ',' << center.x << ',' << center.y << ','
			<< comparison_mode_name(modes[i]) << ',' << status << ','
			<< (report ? report->candidate_count : candidate_centers.size());

		if (report && report->solved)
		{
			csv << ',' << report->selected_facets.size() << ',' << report->selected_roofs.size()
				<< ',' << report->roof_coverage << ',' << report->roof_overlap
				<< ',' << report->roof_fit_p95 << ',' << report->roof_point_coverage
				<< ',' << report->open_roof_edges << ',' << report->data
				<< ',' << report->curvature << ',' << report->boundary << ',' << report->area << ',';
			write_face_ids(csv, report->selected_roofs);
			csv << ',';
			write_face_ids(csv, report->selected_facets);
			csv << ',';
			for (std::size_t j = 0; j < report->selected_roofs.size(); ++j)
			{
				if (j != 0)
					csv << ';';
				const std::size_t id = report->selected_roofs[j];
				if (id < candidate_centers.size())
				{
					const vec3& p = candidate_centers[id];
					csv << p.x << ' ' << p.y << ' ' << p.z;
				}
			}
		}
		else
		{
			csv << ",,,,,,,,,,,,,,";
		}
		if (report)
			csv << ',' << report->overlap_conflicts << ',' << report->support_floor << ',' << report->selection_source;
		else
			csv << ",,,";
		if (modes[i] == output_mode)
			write_shell_report(csv, shell);
		else
			csv << ",,,,,,,,,";
		csv << '\n';
	}
	*out << csv.str();
}

void write_selection_header(std::ostream* out)
{
	if (out)
		*out <<
			"building_id,footprint_x,footprint_y,mode,status,candidate_faces,selected_faces,selected_roof_faces,"
			"roof_coverage,roof_overlap,roof_fit_p95,roof_point_coverage,open_roof_edges,data,curvature,boundary,area,"
			"selected_roof_ids,selected_face_ids,selected_roof_centers_xyz,"
			"overlap_conflicts,support_floor,selection_source,"
			"shell_status,shell_detail,shell_vertices,shell_faces,roof_offset,"
			"shell_p95_before,shell_p95_after,shell_point_coverage_before,shell_point_coverage_after\n";
}

void write_skipped_selection(const FaceSelectionOptions& options, std::size_t building_id,
	const Map::Facet* footprint, const char* status)
{
	write_selection_comparison(options.comparison_csv, building_id, footprint, status);
	write_selection_comparison(options.refinement_baseline_csv, building_id, footprint, status);
}

} // namespace

bool
Reconstruction::reconstruct(PointSet *pset, Map *foot_print, Map *result, LinearProgramSolver::SolverName solver_name,
	bool /*update_display*/, const FaceSelectionOptions& options)
{
	if (!pset)
	{
		Logger::warn("-") << "point cloud data does not exist" << std::endl;
		return false;
	}

	MapFacetAttribute<VertexGroup::Ptr> buildings(foot_print, "buildings");

	write_selection_header(options.comparison_csv);
	write_selection_header(options.refinement_baseline_csv);

	bool success = false;
	StopWatch t;
	t.start();
	std::size_t num = 0;
	ProgressLogger progress(foot_print->size_of_facets());
	KdTreeSearch_var kdtree = new KdTreeSearch;
	kdtree->begin();

	std::size_t idx = 0;
	FOR_EACH_FACET(Map, foot_print, it)
	{
		std::cout << "processing " << ++idx << "/" << foot_print->size_of_facets() << " building..." << std::endl;
		VertexGroup::Ptr g = buildings[it];
		if (!g)
		{
			write_skipped_selection(options, idx, it, "no_building_points");
			continue;
		}
		//ensure the footprint is manifold
		if (!is_simple_polygon(it))
		{
			++num;
			write_skipped_selection(options, idx, it, "non_simple_footprint");
			continue;
		}

		std::vector<VertexGroup::Ptr> &roofs = g->children();
		// If the initial roof extraction found no region, retry with a lower
		// support threshold. The old early `continue` made this retry loop
		// unreachable and silently discarded small or sparse roofs.
		unsigned int min_support = 30;
		for (int attempt = 0; roofs.empty() && attempt < 5; ++attempt)
		{
			extract_building_roof(pset, g, min_support);
			if (min_support > 10)
				min_support = std::max(10u, static_cast<unsigned int>(min_support * 0.7));
		}
		if (roofs.empty())
		{
			write_skipped_selection(options, idx, it, "no_roof_planes");
			continue;
		}

		PointSet::Ptr roof_pset = create_roof_point_set(pset, roofs, g);
		PointSet::Ptr image_pset = create_projected_point_set(roof_pset);

		if (roof_pset->num_points() < 20)
		{
			write_skipped_selection(options, idx, it, "too_few_roof_points");
			continue;
		}
		auto line_segs = compute_line_segment(image_pset, roof_pset, it);
		Map::Ptr building = reconstruct_single_building(roof_pset, *pset, *g, line_segs,
			it, solver_name, options, idx);

		if (building)
		{
			Geom::merge_into_source(result, building);
			success = true;
		}
		roofs.clear();
		progress.next();
	}

	if (num > 0)
		Logger::warn("-") << "encountered " << num << " non-simple foot print "
		<< (num > 1 ? " polygons." : " polygon.") << std::endl;
	//	Logger::out("-") << "reconstruction done. Time: " << t.elapsed() << " sec." << std::endl;

	return success;
}

std::vector<std::vector<int>> Reconstruction::compute_height_field(PointSet *pset, Map::Facet *footprint)
{
	std::vector<vec3> original_points = pset->points();
	std::vector<K::Point_3> result;
	int num = original_points.size();
	for (std::size_t i = 0; i < num; i++)
	{
		vec3 point1 = original_points[i];
		K::Point_3 p(point1.x, point1.y, point1.z); // z stores the height of projection
		result.push_back(p);
	}
	Box3d box = pset->bbox();
	double x_max = box.x_max(), y_max = box.y_max(), x_min = box.x_min(), y_min = box.y_min();
	Delaunay_triangulation dt(result.begin(), result.end());

	// 2d vision of footprint
	Polygon2d plg;
	FacetHalfedgeCirculator fcir(footprint);
	for (; !fcir->end(); ++fcir)
	{
		vec3 q = fcir->halfedge()->vertex()->point();
		const vec2 r(q.x, q.y);
		plg.push_back(r);
	}

	//set the image resolution, a larger value for the sparser or noisy point set, usually (0.15,0.25).
	double point_density = Method::point_density;
	int in_x = (x_max - x_min) / point_density, in_y = (y_max - y_min) / point_density;
	width = ogf_max(in_x, in_y);
	height = width;
	int image_width = width, image_height = height;
	std::vector<std::vector<double>> image(image_width, std::vector<double>(image_height, -1));
	double delta_x = (x_max - x_min) / (image_width), delta_y = (y_max - y_min) / (image_height);
	double delta_res = ogf_max(delta_x, delta_y);
	image_y_min = y_min;
	image_x_min = x_min;
	image_delta_res = delta_res;
	double image_zmin = 1e20, image_zmax = 0;

	for (int j = 0; j < image_width; ++j)
	{
		for (int k = 0; k < image_width; ++k)
		{
			FT x = image_x_min + (k)* image_delta_res;
			FT y = image_y_min + (image_width - j - 1) * image_delta_res;
			Point_3d query_p(x, y, 0);
			vec2 q_p(CGAL::to_double(x), CGAL::to_double(y));
			if (Geom::point_is_in_polygon(plg, q_p))// ensure the pixel point is inside  the footprint
			{
				Face_handle fh = dt.locate(query_p);
				// Footprint pixels can lie outside the point-cloud convex hull.
				// Do not form a height plane from Delaunay's infinite vertex;
				// doing so injects invalid heights into edge detection.
				if (dt.is_infinite(fh)
					|| dt.is_infinite(fh->vertex(0))
					|| dt.is_infinite(fh->vertex(1))
					|| dt.is_infinite(fh->vertex(2)))
				{
					continue;
				}
				auto pt0 = fh->vertex(0)->point();
				auto pt1 = fh->vertex(1)->point();
				auto pt2 = fh->vertex(2)->point();
				K::Plane_3 pl(pt0, pt1, pt2);
				K::Vector_3 dir(0, 0, 1);
				K::Line_3 l(query_p, dir);
				CGAL::Object lp = CGAL::intersection(pl, l);
				if (const Point_3d *pt = CGAL::object_cast<Point_3d>(&lp))
				{
					auto height = pt->z();
					image[j][k] = height;
					if (height > image_zmax)
						image_zmax = height;
					if (height < image_zmin)
						image_zmin = height;
				}
			}

		}

	}

	double delta_z = 255. / (image_zmax - image_zmin);
	std::vector<std::vector<int>> im(width, std::vector<int>(height, 255));
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			auto n = image[i][j];
			if (n == -1)
			{
				im[i][j] = -1;
			}
			else
			{
				im[i][j] = n * delta_z - delta_z * image_zmin;
			}
		}
	}
	return im;
}

std::vector<std::vector<int>> Reconstruction::detect_height_jump(
	PointSet *pset,
	Map::Facet *foot_print,
	double min_height,
	double max_height)
{
	try
	{
		std::vector<std::vector<int>> im =
			compute_height_field(pset, foot_print);

		auto pts = pset->points();
		FacetHalfedgeCirculator cir(foot_print);
		Map::Halfedge *h = cir->halfedge();
		auto ht = h->vertex()->point().z;

		int sp = width;
		if (sp <= 0)
		{
			std::cerr << "Error: width (sp) is not positive: "
				<< sp << std::endl;
			return std::vector<std::vector<int>>(
				width, std::vector<int>(width, 0));
		}

		std::vector<std::vector<int>> adata(im);
		cv::Mat image3(sp, sp, CV_8UC1, cv::Scalar(0));

		for (int i = 0; i < sp; i++)
		{
			for (int j = 0; j < sp; j++)
			{
				if (adata[i][j] != -1)
				{
					float depth = adata[i][j];

					if (depth < 10)
					{
						depth = 10;
					}

					if (depth > 245)
					{
						depth = 245;
					}

					cv::Vec3b d(depth, depth, depth);
					image3.at<uchar>(i, j) = depth;
				}
			}
		}

		if (image3.empty())
		{
			std::cerr << "Error: image3 is empty!" << std::endl;
			return std::vector<std::vector<int>>(
				width, std::vector<int>(width, 0));
		}

		cv::Mat out1, edge;

		int k1 = (sp - 20) * 0.03;
		int kernel_size = std::max(k1, 3);

		if (kernel_size <= 0)
		{
			std::cerr << "Error: kernel_size is not positive: "
				<< kernel_size << std::endl;
			return std::vector<std::vector<int>>(
				width, std::vector<int>(width, 0));
		}

		cv::Mat element = cv::getStructuringElement(
			cv::MORPH_ELLIPSE,
			cv::Size(kernel_size, kernel_size));

		cv::morphologyEx(image3, out1, 3, element);

		int low_threshold =
			(2.0) * 255 / (max_height - ht);
		int high_threshold =
			(min_height - ht) * 255 / (max_height - ht);

		high_threshold = std::max(
			high_threshold,
			2 * low_threshold);

		cv::Canny(
			out1,
			edge,
			low_threshold,
			high_threshold);

		std::vector<std::vector<int>> point(
			width, std::vector<int>(width, 0));

		for (std::size_t i = 0; i < static_cast<std::size_t>(sp); i++)
		{
			for (std::size_t j = 0; j < static_cast<std::size_t>(sp); j++)
			{
				if (edge.at<uchar>(
					static_cast<int>(i),
					static_cast<int>(j)) > 0)
				{
					point[i][j] = 1;
				}
			}
		}

		return point;
	}
	catch (const cv::Exception& e)
	{
		std::cerr << "OpenCV Exception in detect_height_jump: "
			<< e.what() << std::endl;
		std::cerr << "Error code: " << e.code << std::endl;
		std::cerr << "Error description: " << e.err << std::endl;
		std::cerr << "File: " << e.file << std::endl;
		std::cerr << "Line: " << e.line << std::endl;
		throw;
	}
}
std::vector<vec3> Reconstruction::compute_line_segment2(
	PointSet* seg_pset,
	PointSet* roof_pset,
	Map::Facet* footprint
)
{
	std::vector<std::vector<int>> edge_point;
	std::vector<vec3> line_segments;

	// ------------------------------------------------------------
	// 0. 基础防崩检查
	// ------------------------------------------------------------
	if (seg_pset == nullptr || roof_pset == nullptr || footprint == nullptr)
	{
		Logger::out("-") << "skip compute_line_segment: null input." << std::endl;
		return line_segments;
	}

	const std::vector<vec3>& roofpoints = roof_pset->points();

	if (roofpoints.size() <= 70)
	{
		return line_segments;
	}

	std::vector<VertexGroup::Ptr>& groups = roof_pset->groups();

	if (groups.empty())
	{
		Logger::out("-") << "skip compute_line_segment: roof groups empty." << std::endl;
		return line_segments;
	}

	// ------------------------------------------------------------
	// 1. 检查 footprint 是否有有效 halfedge
	// ------------------------------------------------------------
	FacetHalfedgeCirculator cir_check(footprint);
	Map::Halfedge* h_check = cir_check->halfedge();

	if (h_check == nullptr || h_check->vertex() == nullptr)
	{
		Logger::out("-") << "skip compute_line_segment: invalid footprint halfedge." << std::endl;
		return line_segments;
	}

	double foot_height = h_check->vertex()->point().z;

	// ------------------------------------------------------------
	// 2. 从 roof groups 中统计高度范围
	// ------------------------------------------------------------
	double min_height = 1e10;
	double max_height = -1e10;

	std::vector<double> height_seq;
	height_seq.reserve(groups.size());

	for (std::size_t gi = 0; gi < groups.size(); ++gi)
	{
		VertexGroup* g = groups[gi];

		if (g == nullptr)
		{
			continue;
		}

		if (g->empty())
		{
			continue;
		}

		const Plane3d& plane = g->plane();

		// 原逻辑：只保留相对水平的 roof plane
		if (std::abs(plane.normal().z) < 0.3f)
		{
			continue;
		}

		vec3 cen(0, 0, 0);
		std::size_t valid_count = 0;

		for (std::size_t pi = 0; pi < g->size(); ++pi)
		{
			int idx = g->at(pi);

			// 防止 group 中的点索引越界
			if (idx < 0 || idx >= static_cast<int>(roofpoints.size()))
			{
				continue;
			}

			const vec3& p = roofpoints[idx];

			if (p.z > max_height)
			{
				max_height = p.z;
			}

			cen += p;
			++valid_count;
		}

		if (valid_count == 0)
		{
			continue;
		}

		cen /= static_cast<float>(valid_count);
		height_seq.push_back(cen.z);
	}

	if (height_seq.empty())
	{
		Logger::out("-") << "skip compute_line_segment: no valid roof height." << std::endl;
		return line_segments;
	}

	if (max_height < -1e9)
	{
		Logger::out("-") << "skip compute_line_segment: invalid max_height." << std::endl;
		return line_segments;
	}

	std::sort(height_seq.begin(), height_seq.end());

	for (std::size_t j = 0; j < height_seq.size(); ++j)
	{
		double height_c = height_seq[j];

		if (height_c - foot_height > 1.0)
		{
			min_height = height_c;
			break;
		}
	}

	if (min_height > 1e5)
	{
		min_height = foot_height + 1.0;
	}

	if (max_height <= min_height)
	{
		Logger::out("-") << "skip compute_line_segment: invalid height range. "
			<< "min_height = " << min_height
			<< ", max_height = " << max_height
			<< std::endl;

		return line_segments;
	}

	// ------------------------------------------------------------
	// 3. 检测高度跳变边缘
	// ------------------------------------------------------------
	edge_point = detect_height_jump(seg_pset, footprint, min_height, max_height);

	if (edge_point.empty())
	{
		Logger::out("-") << "skip edge_simplify: edge_point empty." << std::endl;
		return line_segments;
	}

	// ------------------------------------------------------------
	// 4. 检查 edge_point 是否退化
	//    注意：这里 edge_point 更像二值边缘图，不是点索引链。
	//    所以不要按点索引过滤，而是统计非零边缘像素数量。
	// ------------------------------------------------------------
	std::size_t row_count = edge_point.size();
	std::size_t max_col_count = 0;
	std::size_t nonzero_edge_pixels = 0;
	std::size_t nonempty_rows = 0;

	for (std::size_t r = 0; r < edge_point.size(); ++r)
	{
		if (!edge_point[r].empty())
		{
			++nonempty_rows;
		}

		if (edge_point[r].size() > max_col_count)
		{
			max_col_count = edge_point[r].size();
		}

		for (std::size_t c = 0; c < edge_point[r].size(); ++c)
		{
			if (edge_point[r][c] != 0)
			{
				++nonzero_edge_pixels;
			}
		}
	}

	// 这个阈值可以调。你的异常 case 只有 1 个非零点，必须跳过。
	const std::size_t min_valid_edge_pixels = 5;

	if (nonempty_rows < 2 || max_col_count < 2 || nonzero_edge_pixels < 5)
	{
		Logger::out("-") << "skip edge_simplify: degenerate edge_point. "
			<< "rows = " << row_count
			<< ", nonempty_rows = " << nonempty_rows
			<< ", max_cols = " << max_col_count
			<< ", nonzero_edge_pixels = " << nonzero_edge_pixels
			<< std::endl;

		return line_segments;
	}

	// ------------------------------------------------------------
	// 5. 正常简化边缘线段
	// ------------------------------------------------------------
	FT tolerance = 2.0;
	Otr2_edge_sim otr2(image_x_min, image_y_min, image_delta_res);

	line_segments = otr2.edge_simplify(edge_point, footprint, tolerance);

	return line_segments;
}

std::vector<vec3> Reconstruction::compute_line_segment(PointSet *seg_pset,
	PointSet *roof_pset,
	Map::Facet *footprint)
{
	std::vector<std::vector<int>> edge_point;
	std::vector<vec3> line_segments;
	if (roof_pset->points().size() > 70)
	{
		std::vector<VertexGroup::Ptr> &groups = roof_pset->groups();
		const std::vector<vec3> &roofpoints = roof_pset->points();
		std::vector<vec3> boundary_edge;
		double min_height = 1e10;
		double max_height = -1e10;

		std::vector<double> height_seq;
		for (std::size_t i = 0; i < groups.size(); ++i)
		{
			VertexGroup *g = groups[i];
			const Plane3d &plane = g->plane();
			if (std::abs(plane.normal().z) < 0.3f)
				continue;
			auto rf = g->point_set()->points();
			double avg_z = 0.;
			vec3 cen(0, 0, 0);
			std::size_t num_input = g->size();
			for (std::size_t i = 0; i < num_input; ++i)
			{
				int idx = g->at(i);
				const vec3 &p = rf[idx];
				if (p.z > max_height)
				{
					max_height = p.z;
				}
				cen += p;

			}
			cen /= num_input;
			height_seq.push_back(cen.z);
		}

		std::sort(height_seq.begin(), height_seq.end());
		FacetHalfedgeCirculator cir(footprint);
		Map::Halfedge *h = cir->halfedge();
		auto foot_height = h->vertex()->point().z;
		for (int j = 0; j < height_seq.size(); ++j)
		{
			auto height_c = height_seq[j];
			if (height_c - foot_height > 1.0)
			{
				min_height = height_c;
				break;
			}
		}
		if (min_height > 1e5)
		{
			min_height = foot_height + 1;
		}
		edge_point = detect_height_jump(seg_pset, footprint, min_height, max_height);
		if (edge_point.empty())
		{
			return line_segments;
		}

		std::size_t nonzero_edge_pixels = 0;

		for (std::size_t r = 0; r < edge_point.size(); ++r)
		{
			for (std::size_t c = 0; c < edge_point[r].size(); ++c)
			{
				if (edge_point[r][c] != 0)
				{
					++nonzero_edge_pixels;
				}
			}
		}

		//无法形成有效线段，直接跳过
		if (nonzero_edge_pixels < 2)
		{
			return line_segments;
		}

		FT tolerance = 2.0;
		Otr2_edge_sim otr2(image_x_min, image_y_min, image_delta_res);
		line_segments = otr2.edge_simplify(edge_point, footprint, tolerance);
	}
	return line_segments;
}


Map::Ptr Reconstruction::reconstruct_single_building(PointSet *roof_pset,
	const PointSet& scene_points, const VertexGroup& footprint_points,
	std::vector<vec3> line_segments,
	Map::Facet *footprint,
	LinearProgramSolver::SolverName solver_name,
	const FaceSelectionOptions& options,
	std::size_t building_id)
{

	// refine planes
	HypothesisGenerator hypo(roof_pset);
	hypo.refine_planes();
	// generate candidate faces
	PolyFitInfo polyfit_info;
	Map::Ptr hypothesis = hypo.generate(&polyfit_info, footprint, line_segments);
	if (!hypothesis)
	{
		write_skipped_selection(options, building_id, footprint, "no_candidates");
		return nil;
	}
	std::vector<Plane3d *> a = hypo.get_vertical_planes();
	// generate quality measures
	polyfit_info.generate(roof_pset, hypothesis, a
		, false);


	FaceSelection selector(roof_pset, hypothesis);
	const bool refine_fit = options.mode == FaceSelectionMode::Guarded;
	struct FeedbackCandidate {
		Map::Ptr surfaces;
		FaceSelectionReport report;
	};
	std::vector<FeedbackCandidate> feedback_candidates;
	FaceSelectionFeedback feedback;
	if (refine_fit && options.refine_selection)
	{
		feedback = [&](const FaceSelectionReport& report) {
			CandidateMapCopier copier;
			Map::Ptr surfaces = copier.copy_selected(hypothesis, report.selected_facets);
			if (surfaces)
				feedback_candidates.push_back({surfaces, report});
			else
				Logger::warn("-") << "building " << building_id
					<< ": could not copy P95 feedback candidate surfaces" << std::endl;
		};
	}
	bool selected = false;
	std::vector<vec3> candidate_centers;
	std::vector<FaceSelectionReport> reports;
	if (options.comparison_csv || options.refinement_baseline_csv)
	{
		candidate_centers.reserve(hypothesis->size_of_facets());
		FOR_EACH_FACET(Map, hypothesis, it)
			candidate_centers.push_back(facet_vertex_center(it));
		selected = selector.optimize_comparison(&polyfit_info, footprint, a, solver_name,
			comparison_modes(), options.mode, reports, feedback);
	}
	else
		selected = selector.optimize(&polyfit_info, footprint, a, solver_name, options.mode, feedback);

	if (!selected && feedback_candidates.empty())
	{
		write_selection_comparison(options.comparison_csv, building_id, footprint, "comparison_failed",
			reports, candidate_centers, options.mode);
		write_selection_comparison(options.refinement_baseline_csv, building_id, footprint, "comparison_failed",
			reports, candidate_centers, options.mode);
		return nil;
	}

	const auto assemble_shell = [&](const Map::Ptr& surfaces, ShellReport& report, bool original) -> Map::Ptr {
		std::vector<std::size_t> roof_ids;
		MapFacetAttribute<Plane3d*> supporting_plane;
		supporting_plane.bind_if_defined(surfaces, "FacetSupportingPlane");
		if (supporting_plane.is_bound())
		{
			std::size_t id = 0;
			FOR_EACH_FACET(Map, surfaces, it)
			{
				if (supporting_plane[it] && std::find(a.begin(), a.end(), supporting_plane[it]) == a.end())
					roof_ids.push_back(id);
				++id;
			}
		}

		extrude_boundary_to_ground(surfaces, Geom::facet_plane(footprint), &polyfit_info);
		Geom::merge_into_source(surfaces, footprint);

		std::vector<Map::Facet*> stitched_faces;
		WatertightMesh::LowRoofRepair low_roof_repair{
			roof_ids, scene_points.points(), scene_points.normals(), footprint_points, {}, 0, 0
		};
		Map::Ptr shell = WatertightMesh::stitch(surfaces, report.detail,
			refine_fit ? &stitched_faces : nullptr, &low_roof_repair);
		if (!shell)
		{
			report.status = "shell_failed";
			if (original)
				Logger::warn("-") << "building " << building_id << ": " << report.detail << std::endl;
			return nil;
		}

		report.status = "watertight";
		const bool added_roof = !low_roof_repair.added_roof_faces.empty();
		const bool closed_boundary = low_roof_repair.boundary_face_count > 0;
		if (added_roof)
		{
			roof_ids.insert(roof_ids.end(), low_roof_repair.added_roof_faces.begin(),
				low_roof_repair.added_roof_faces.end());
			report.detail = "Local low roof repair: " +
				std::to_string(low_roof_repair.added_roof_faces.size()) + " faces, " +
				std::to_string(low_roof_repair.support_points) + " supporting points";
		}
		if (closed_boundary)
		{
			if (added_roof)
				report.detail += ". ";
			report.detail += "Local boundary closure: " +
				std::to_string(low_roof_repair.boundary_face_count) + " transition faces";
		}
		if (original && (added_roof || closed_boundary))
			Logger::out("-") << "building " << building_id << ": " << report.detail << std::endl;
		if (refine_fit)
			report.fit = refine_closed_roof(shell, footprint, *roof_pset, stitched_faces,
				roof_ids, report.detail, !added_roof && !closed_boundary);
		report.vertices = shell->size_of_vertices();
		report.faces = shell->size_of_facets();
		return shell;
	};

	ShellReport shell_report;
	Map::Ptr shell;
	if (selected)
		shell = assemble_shell(hypothesis, shell_report, true);
	write_selection_comparison(options.refinement_baseline_csv, building_id, footprint, "comparison_failed",
		reports, candidate_centers, options.mode, shell_report);
	if (shell && options.refinement_baseline_model)
		Geom::merge_into_source(options.refinement_baseline_model, shell);

	for (auto& candidate : feedback_candidates)
	{
		ShellReport candidate_shell_report;
		Map::Ptr candidate_shell = assemble_shell(candidate.surfaces, candidate_shell_report, false);
		if (!candidate_shell)
			continue;
		const auto& fit = candidate_shell_report.fit;
		const auto& incumbent_fit = shell_report.fit;
		if (shell && (!std::isfinite(fit.p95_after) || !std::isfinite(incumbent_fit.p95_after) ||
			fit.p95_after >= incumbent_fit.p95_after || fit.point_count != incumbent_fit.point_count ||
			fit.near_after < incumbent_fit.near_after))
			continue;
		shell = candidate_shell;
		shell_report = std::move(candidate_shell_report);
		if (!reports.empty())
			reports.back() = std::move(candidate.report); // Guarded is last in comparison_modes().
		Logger::out("-") << "building " << building_id << ": accepted P95 feedback shell" << std::endl;
	}
	write_selection_comparison(options.comparison_csv, building_id, footprint, "comparison_failed",
		reports, candidate_centers, options.mode, shell_report);
	return shell;
}


#define SIMPLE_EXTRUSION


void Reconstruction::extrude_boundary_to_ground(Map *model, const Plane3d &ground, PolyFitInfo *polyfit_info)
{
#ifdef SIMPLE_EXTRUSION // a planar wall might contain multiple pieces

	MapHalfedgeAttribute<bool> is_boundary(model, "is_boundary");
	std::vector<Polygon3d> polygons;
	FOR_EACH_HALFEDGE(Map, model, it)
	{
		if (is_boundary[it])
		{
			/*
			b_______a
			|              |
			|              |
			|_______|
			c             d
			*/
			Polygon3d plg;
			const vec3 &a = it->vertex()->point();
			plg.push_back(a);
			const vec3 &b = it->opposite()->vertex()->point();
			plg.push_back(b);
			const vec3 &c = ground.projection(b);
			plg.push_back(c);
			const vec3 &d = ground.projection(a);
			plg.push_back(d);
			auto dis = length(c - d);
			if (dis > 1e-4)
			{
				polygons.push_back(plg);
			}
		}
	}

	if (polygons.empty())
		return;
	MapFacetAttribute<Color> color(model, "color");
	MapBuilder builder(model);
	builder.begin_surface();
	int id = 0;
	for (std::size_t i = 0; i < polygons.size(); ++i)
	{
		builder.begin_facet();
		const Polygon3d &plg = polygons[i];
		for (std::size_t j = 0; j < plg.size(); ++j)
		{
			builder.add_vertex(plg[j]);
			builder.add_vertex_to_facet(id);
			++id;
		}
		builder.end_facet();
		color[builder.current_facet()] = random_color();
	}
	builder.end_surface();

#endif
}

Map *Reconstruction::generate_polygon(PointSet *pSet, double footprint_height, double density)
{
	//get the alpha shape of the point set
	auto alpha_boundary = AlphaShapeBoundary::apply(pSet, 1.5);
	Method::ground_height = footprint_height;
	Method::point_density = density;

	Map* new_foot = new Map;
	MapBuilder builder(new_foot);
	builder.begin_surface();
	builder.begin_facet();
	int ind = 0;
	for (int i = 0; i < alpha_boundary.size(); ++i)
	{
		auto p = alpha_boundary[i];
		builder.add_vertex(vec3(p.x, p.y, footprint_height));
		builder.add_vertex_to_facet(ind);
		++ind;
	}
	builder.end_facet();
	builder.end_surface();
	return new_foot;
}





