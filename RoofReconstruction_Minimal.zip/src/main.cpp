/*
Copyright (C) 2017  Liangliang Nan
https://3d.bk.tudelft.nl/liangliang/ - liangliang.nan@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
#include "basic/file_utils.h"
#include "method/reconstruction.h"
#include "model/map.h"
#include "model/map_io.h"
#include "model/point_set.h"
#include "model/point_set_io.h"

#include <cstdlib>
#include <fstream>
#include <initializer_list>
#include <iostream>
#include <memory>
#include <set>
#include <string>

namespace {

constexpr char supervoxel_notice[] = "The latest supervoxel implementation is coming soon.";

void print_usage(std::ostream& out)
{
    out << "roof_reconstruct <cloud.ply> <footprint.obj> <output.obj>\n"
        << "    [guarded-refined|guarded|compare-refined|compare|supervoxel] [report.csv]\n"
        << "    [baseline.obj baseline.csv]\n"
        << "Default mode is guarded-refined. Both compare modes export a CSV report.\n"
        << "Paired baseline outputs require compare-refined and an explicit report path.\n"
        << "The supervoxel mode is reserved. " << supervoxel_notice << '\n';
}

bool distinct_paths(std::initializer_list<std::string> paths)
{
    std::set<std::string> seen;
    for (const auto& path : paths) {
        if (path.empty())
            continue;
        std::string absolute = FileUtils::get_absolute_path(path);
#ifdef _WIN32
        absolute = FileUtils::convert_to_unix_style(absolute);
        for (char& ch : absolute)
            if (ch >= 'A' && ch <= 'Z')
                ch = static_cast<char>(ch - 'A' + 'a');
#endif
        if (!seen.insert(absolute).second)
            return false;
    }
    return true;
}

bool finish_report(std::ofstream& report, const std::string& path)
{
    if (path.empty())
        return true;
    report.close();
    if (report)
        return true;
    std::cerr << "Could not finish report " << path << '\n';
    return false;
}

} // namespace

int main(int argc, char** argv)
{
    if (argc == 2 && std::string(argv[1]) == "--help") {
        print_usage(std::cout);
        return EXIT_SUCCESS;
    }
    if (argc < 4 || argc == 7 || argc > 8) {
        print_usage(std::cerr);
        return EXIT_FAILURE;
    }

    const std::string cloud_path = argv[1];
    const std::string footprint_path = argv[2];
    const std::string output_path = argv[3];
    const std::string mode = argc >= 5 ? argv[4] : "guarded-refined";
    if (mode == "supervoxel") {
        // Reserved for integrating the upcoming supervoxel backend.
        std::cerr << supervoxel_notice << '\n';
        return EXIT_FAILURE;
    }
    const bool compare = mode == "compare" || mode == "compare-refined";
    const bool refined = mode == "guarded-refined" || mode == "compare-refined";
    const bool paired = argc == 8;
    if (!compare && !refined && mode != "guarded") {
        std::cerr << "Unknown mode " << mode << '\n';
        print_usage(std::cerr);
        return EXIT_FAILURE;
    }
    if ((argc >= 6 && !compare) || (paired && !refined)) {
        print_usage(std::cerr);
        return EXIT_FAILURE;
    }

    const std::string report_path = compare
        ? (argc >= 6 ? argv[5] : output_path + ".comparison.csv") : "";
    const std::string baseline_path = paired ? argv[6] : "";
    const std::string baseline_report_path = paired ? argv[7] : "";
    if (FileUtils::extension_in_lower_case(cloud_path) != "ply"
        || FileUtils::extension_in_lower_case(footprint_path) != "obj"
        || FileUtils::extension_in_lower_case(output_path) != "obj"
        || (compare && FileUtils::extension_in_lower_case(report_path) != "csv")
        || (paired && (FileUtils::extension_in_lower_case(baseline_path) != "obj"
            || FileUtils::extension_in_lower_case(baseline_report_path) != "csv"))) {
        print_usage(std::cerr);
        return EXIT_FAILURE;
    }
    if (!distinct_paths({cloud_path, footprint_path, output_path, report_path,
                         baseline_path, baseline_report_path})) {
        std::cerr << "Use distinct paths for input and output files.\n";
        return EXIT_FAILURE;
    }

    std::unique_ptr<PointSet> cloud(PointSetIO::read(cloud_path));
    std::unique_ptr<Map> footprint(MapIO::read(footprint_path));
    if (!cloud || !footprint)
        return EXIT_FAILURE;

    FaceSelectionOptions options;
    options.mode = FaceSelectionMode::Guarded;
    options.refine_selection = refined;
    std::ofstream report;
    if (compare) {
        report.open(report_path.c_str());
        if (!report) {
            std::cerr << "Could not open report " << report_path << '\n';
            return EXIT_FAILURE;
        }
        options.comparison_csv = &report;
    }

    std::ofstream baseline_report;
    std::unique_ptr<Map> baseline;
    if (paired) {
        baseline_report.open(baseline_report_path.c_str());
        if (!baseline_report) {
            std::cerr << "Could not open report " << baseline_report_path << '\n';
            return EXIT_FAILURE;
        }
        baseline.reset(new Map);
        options.refinement_baseline_csv = &baseline_report;
        options.refinement_baseline_model = baseline.get();
    }

    Reconstruction reconstruction;
    reconstruction.segmentation(cloud.get(), footprint.get());
    reconstruction.extract_roofs(cloud.get(), footprint.get());
    std::unique_ptr<Map> result(new Map);
    const bool status = reconstruction.reconstruct(cloud.get(), footprint.get(), result.get(),
        LinearProgramSolver::SCIP, false, options);

    const bool report_finished = finish_report(report, report_path);
    const bool baseline_report_finished = finish_report(baseline_report, baseline_report_path);
    if (!report_finished || !baseline_report_finished)
        return EXIT_FAILURE;
    if (!status || result->size_of_facets() == 0) {
        std::cerr << "No building was reconstructed.\n";
        return EXIT_FAILURE;
    }
    if (!MapIO::save(output_path, result.get()))
        return EXIT_FAILURE;
    if (paired && !MapIO::save(baseline_path, baseline.get()))
        return EXIT_FAILURE;

    std::cout << "Reconstruction saved to " << output_path << '\n';
    return EXIT_SUCCESS;
}
