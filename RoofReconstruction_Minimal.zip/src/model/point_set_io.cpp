/*
Copyright (C) 2017  Liangliang Nan
https://3d.bk.tudelft.nl/liangliang/ - liangliang.nan@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "point_set_io.h"
#include "point_set_serializer_ply.h"
#include "../model/point_set.h"
#include "../basic/stop_watch.h"
#include "../basic/file_utils.h"
#include "../basic/logger.h"

#include <fstream>


PointSet* PointSetIO::read(const std::string& file_name)
{
	std::ifstream in(file_name.c_str()) ;
	if(in.fail()) {
		Logger::err("-") << "cannot open file: " << file_name << std::endl;
		return nil;
	}
	in.close();

	Logger::out("-") << "reading file..." << std::endl;

	std::string ext = FileUtils::extension(file_name);
	String::to_lowercase(ext);
	if (ext != "ply") {
		Logger::err("-") << "reading file failed (only PLY is supported)" << std::endl;
		return nil;
	}

	StopWatch w;
	PointSet* pset = new PointSet;
	pset->set_name(file_name);
	PointSetSerializer_ply::load(pset, file_name);
		
	if (pset->num_points() < 1) {
		Logger::err("-") << "reading file failed (no data exist)" << std::endl;
		delete pset;
		return nil;
	}

	Logger::out("-") << "done. " << w.elapsed() << " sec." << std::endl;

	return pset;
}

bool PointSetIO::save(const std::string& file_name, const PointSet* point_set) {
	if (!point_set) {
		Logger::err("-") << "Point set is null" << std::endl;
		return false;
	}
	std::string ext = FileUtils::extension(file_name);
	String::to_lowercase(ext);
	if (ext != "ply") {
		Logger::err("-") << "saving file failed (only PLY is supported)" << std::endl;
		return false;
	}
	
	std::ofstream out(file_name.c_str()) ;
	if(out.fail()) {
		Logger::err("-") << "cannot open file: \'" << file_name << "\' for writing" << std::endl;
		return false;
	}
	Logger::out("-") << "saving file..." << std::endl;
	out.close();

	StopWatch w;
	PointSetSerializer_ply::save(point_set, file_name);
	Logger::out("-") << "done. " << w.elapsed() << " sec." << std::endl;
	return true;
}
